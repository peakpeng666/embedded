/* STM32F407ZGT6，8 MHz 晶体，VDD 2.7~3.6 V。
 * 加入 CubeMX 的 HAL 工程；不要和 SPL 目录一起编译。
 * PF9: LED0，低电平亮；PE4: KEY0，按下接地。使用前核对板卡原理图。
 */
#include "stm32f4xx_hal.h"

#if !defined(STM32F407xx)
#error "This example is for STM32F407xx only"
#endif
typedef char HSE_must_be_8MHz[(HSE_VALUE == 8000000U) ? 1 : -1];

volatile uint32_t observed_sysclk_hz;
volatile uint32_t observed_hclk_hz;
volatile uint32_t observed_pclk1_hz;
volatile uint32_t observed_pclk2_hz;
volatile uint32_t fault_code;

static void Stop_On_Error(uint32_t code)
{
    fault_code = code;             /* 调试器观察；出错不继续假装时钟正常 */
    __disable_irq();
    for (;;) { __NOP(); }
}

/* 仅在复位后的 main 初始化阶段调用，不是运行时任意变频函数。 */
static void Clock_168MHz_Init(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    osc.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    osc.HSEState = RCC_HSE_ON;      /* 晶体模式；外部有源时钟应改 BYPASS */
    osc.PLL.PLLState = RCC_PLL_ON;
    osc.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    osc.PLL.PLLM = 8;
    osc.PLL.PLLN = 336;
    osc.PLL.PLLP = RCC_PLLP_DIV2;
    osc.PLL.PLLQ = 7;
    if (HAL_RCC_OscConfig(&osc) != HAL_OK) {
        Stop_On_Error(1);
    }

    clk.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK |
                    RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    clk.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    clk.AHBCLKDivider = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider = RCC_HCLK_DIV4;
    clk.APB2CLKDivider = RCC_HCLK_DIV2;
    /* 升频前设置 Flash 等待周期；HAL 同时更新 SystemCoreClock 和 tick。 */
    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_5) != HAL_OK) {
        Stop_On_Error(2);
    }
}

static void GPIO_Led_Key_Init(void)
{
    GPIO_InitTypeDef gpio = {0};
    __HAL_RCC_GPIOF_CLK_ENABLE();
    __HAL_RCC_GPIOE_CLK_ENABLE();

    /* 先写初值，再改输出模式，减少上电闪亮。 */
    HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9, GPIO_PIN_SET);
    gpio.Pin = GPIO_PIN_9;
    gpio.Mode = GPIO_MODE_OUTPUT_PP;
    gpio.Pull = GPIO_NOPULL;
    gpio.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOF, &gpio);

    gpio.Pin = GPIO_PIN_4;
    gpio.Mode = GPIO_MODE_INPUT;
    gpio.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOE, &gpio);
}

int main(void)
{
    if (HAL_Init() != HAL_OK) { Stop_On_Error(3); }
    Clock_168MHz_Init();
    GPIO_Led_Key_Init();

    /* 以下是按寄存器和 HSE_VALUE 推算的值，不是频率计测量结果。 */
    observed_sysclk_hz = HAL_RCC_GetSysClockFreq();
    observed_hclk_hz = HAL_RCC_GetHCLKFreq();
    observed_pclk1_hz = HAL_RCC_GetPCLK1Freq();
    observed_pclk2_hz = HAL_RCC_GetPCLK2Freq();
    if (observed_sysclk_hz != 168000000U ||
        observed_hclk_hz != 168000000U ||
        observed_pclk1_hz != 42000000U ||
        observed_pclk2_hz != 84000000U) { Stop_On_Error(4); }

    for (;;) {
        GPIO_PinState key = HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_4);
        HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9,
                          key == GPIO_PIN_RESET ? GPIO_PIN_RESET : GPIO_PIN_SET);
        HAL_Delay(10);             /* 主循环中调用；不在中断里阻塞 */
    }
}
