/* CubeMX 已生成 SysTick_Handler 时，保留原文件，不要再编译本文件。
 * 空白 HAL 模板缺少该处理函数时，才把本文件加入工程。
 * 本例采用默认 SysTick 时基，没有 RTOS，也没有 TIM 时基重载。
 */
#include "stm32f4xx_hal.h"

void SysTick_Handler(void)
{
    HAL_IncTick();
    /* 如果原工程使用 HAL 的 SysTick 回调，可保留以下调用。 */
    HAL_SYSTICK_IRQHandler();
}
