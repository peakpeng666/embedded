/* STM32F407ZGT6 + 标准外设库；8 MHz 晶体，VDD 2.7~3.6 V。
 * 必须使用本目录的 reset-only system_stm32f4xx.c。
 * PF9 LED0、PE4 KEY0 均低有效；不要和 HAL 目录一起编译。
 */
#include "stm32f4xx.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_flash.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_pwr.h"

#if !defined(STM32F40_41xxx)
#error "Select STM32F40_41xxx for the SPL F407 example"
#endif
typedef char HSE_must_be_8MHz[(HSE_VALUE == 8000000U) ? 1 : -1];

static volatile uint32_t tick_ms;
volatile RCC_ClocksTypeDef observed_clocks;
volatile uint32_t fault_code;

static void Stop_On_Error(uint32_t code)
{
    fault_code = code;
    __disable_irq();
    for (;;) { __NOP(); }
}

/* 等待次数上限用于防止外部晶体损坏时无限等待，不是精确毫秒超时。 */
static int Wait_Ready(uint8_t flag)
{
    uint32_t remaining = 1000000U;
    while (RCC_GetFlagStatus(flag) == RESET) {
        if (remaining == 0U) { return 0; }
        --remaining;
    }
    return 1;
}

static int Clock_168MHz_Init(void)
{
    uint32_t remaining;
    /* 本例从复位的 HSI 状态进入，禁止拿来直接重配正在运行的 PLL。 */
    if (RCC_GetSYSCLKSource() != 0U ||
        RCC_GetFlagStatus(RCC_FLAG_PLLRDY) != RESET) { return 0; }

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
    (void)RCC->APB1ENR;
    /* F407 的 VOS 是 bit14 单比特；旧 SPL 的双比特常量还覆盖其他型号。 */
    PWR->CR |= (1UL << 14);
    (void)PWR->CR;
    FLASH_SetLatency(FLASH_Latency_5);
    if ((FLASH->ACR & FLASH_ACR_LATENCY) != FLASH_Latency_5) { return 0; }
    FLASH_InstructionCacheCmd(ENABLE);
    FLASH_DataCacheCmd(ENABLE);

    RCC_HCLKConfig(RCC_SYSCLK_Div1);
    RCC_PCLK1Config(RCC_HCLK_Div4);
    RCC_PCLK2Config(RCC_HCLK_Div2);
    RCC_HSEConfig(RCC_HSE_ON);
    if (!Wait_Ready(RCC_FLAG_HSERDY)) { return 0; }
    RCC_PLLConfig(RCC_PLLSource_HSE, 8, 336, 2, 7);
    RCC_PLLCmd(ENABLE);
    if (!Wait_Ready(RCC_FLAG_PLLRDY)) { return 0; }
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
    remaining = 1000000U;
    while (RCC_GetSYSCLKSource() != 0x08U) {
        if (remaining == 0U) { return 0; }
        --remaining;
    }
    SystemCoreClockUpdate();
    return SystemCoreClock == 168000000U;
}

static void GPIO_Led_Key_Init(void)
{
    GPIO_InitTypeDef gpio;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF | RCC_AHB1Periph_GPIOE, ENABLE);
    (void)RCC->AHB1ENR;
    GPIO_SetBits(GPIOF, GPIO_Pin_9);
    GPIO_StructInit(&gpio);
    gpio.GPIO_Pin = GPIO_Pin_9;
    gpio.GPIO_Mode = GPIO_Mode_OUT;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_Speed = GPIO_Speed_2MHz;
    gpio.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOF, &gpio);
    gpio.GPIO_Pin = GPIO_Pin_4;
    gpio.GPIO_Mode = GPIO_Mode_IN;
    gpio.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOE, &gpio);
}

/* 全工程只能定义一个 SysTick_Handler。已有 it.c 时把此函数移入那里。 */
void SysTick_Handler(void)
{
    ++tick_ms;
}

static void Delay_ms(uint32_t ms)
{
    uint32_t start;
    if (ms == 0U) { return; }
    start = tick_ms;
    while ((uint32_t)(tick_ms - start) < ms) { __NOP(); }
}

int main(void)
{
    RCC_ClocksTypeDef clocks;
    if (!Clock_168MHz_Init()) { Stop_On_Error(1); }
    GPIO_Led_Key_Init();
    RCC_GetClocksFreq(&clocks);     /* 计算值，不是实际测量值 */
    observed_clocks = clocks;
    if (clocks.SYSCLK_Frequency != 168000000U ||
        clocks.HCLK_Frequency != 168000000U ||
        clocks.PCLK1_Frequency != 42000000U ||
        clocks.PCLK2_Frequency != 84000000U) { Stop_On_Error(2); }

    /* CMSIS 配置 HCLK 源、LOAD=168000-1、允许中断并启动计数。 */
    if (SysTick_Config(SystemCoreClock / 1000U) != 0U) { Stop_On_Error(3); }
    NVIC_SetPriority(SysTick_IRQn, 15U);
    for (;;) {
        if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4) == Bit_RESET) {
            GPIO_ResetBits(GPIOF, GPIO_Pin_9);
        } else {
            GPIO_SetBits(GPIOF, GPIO_Pin_9);
        }
        Delay_ms(10);              /* 仅在线程态且中断使能时调用 */
    }
}
