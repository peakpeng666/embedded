/* 本例专用 CMSIS 系统层：复位后保持 HSI 16 MHz。
 * 替代模板的同名文件，不能两份一起链接。仅适用于 F407 从 Flash 正常复位。
 * main 中再调用 Clock_168MHz_Init，便于观察完整时钟配置过程。
 */
#include "stm32f4xx.h"

uint32_t SystemCoreClock = HSI_VALUE;

void SystemInit(void)
{
#if (__FPU_PRESENT == 1) && (__FPU_USED == 1)
    SCB->CPACR |= (0xFUL << 20);
#endif
    RCC->CR |= RCC_CR_HSION;
    RCC->CFGR = 0;
    RCC->CR &= ~(RCC_CR_HSEON | RCC_CR_CSSON | RCC_CR_PLLON);
    RCC->PLLCFGR = 0x24003010U;
    RCC->CR &= ~RCC_CR_HSEBYP;
    RCC->CIR = 0;
    SCB->VTOR = FLASH_BASE;         /* 没有 bootloader，向量表位于 Flash 起始处 */
}

void SystemCoreClockUpdate(void)
{
    static const uint8_t ahb_shift[16] = {
        0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 6, 7, 8, 9
    };
    uint32_t source = RCC->CFGR & RCC_CFGR_SWS;
    uint32_t clock;
    if (source == RCC_CFGR_SWS_HSE) {
        clock = HSE_VALUE;
    } else if (source == RCC_CFGR_SWS_PLL) {
        uint32_t reg = RCC->PLLCFGR;
        uint32_t m = reg & 0x3FU;
        uint32_t n = (reg >> 6) & 0x1FFU;
        uint32_t p = (((reg >> 16) & 3U) + 1U) * 2U;
        uint32_t input = (reg & RCC_PLLCFGR_PLLSRC_HSE) ? HSE_VALUE : HSI_VALUE;
        /* 非法配置不做除零；正常例程不会到达此分支。 */
        clock = m == 0U ? 0U : (uint32_t)(((uint64_t)input * n) / (m * p));
    } else {
        clock = HSI_VALUE;
    }
    SystemCoreClock = clock >> ahb_shift[(RCC->CFGR >> 4) & 0xFU];
}
