#include "delay_poll.h"

void Delay_Loops(volatile uint32_t loops)
{
    while (loops != 0U) {
        --loops;
    }
}
