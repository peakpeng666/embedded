/* 可选：Cortex-M4 DWT 周期计数器轮询，不改 SysTick 的任何寄存器。
 * 初始化前提：系统时钟已经稳定，SystemCoreClock 与 HCLK 一致。
 * 适用于本例的短延时；中断会使墙上时间增长，不保证严格脉冲宽度。
 */
#include "stm32f4xx.h"
#include "delay_poll.h"

static uint32_t poll_clock_hz;

int Delay_Poll_Init(void)
{
    uint32_t before;
    uint32_t i;
    poll_clock_hz = 0U;
    SystemCoreClockUpdate();
    if (SystemCoreClock == 0U || SystemCoreClock > 168000000U) { return 0; }
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    if ((DWT->CTRL & DWT_CTRL_NOCYCCNT_Msk) != 0U) { return 0; }
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    /* 不把 CYCCNT 清零，避免干扰已经使用该计数器的观察代码。 */
    before = DWT->CYCCNT;
    for (i = 0U; i < 32U; ++i) { __NOP(); }
    if (DWT->CYCCNT == before) { return 0; }
    poll_clock_hz = SystemCoreClock;
    return 1;
}

int Delay_Poll_us(uint32_t us)
{
    if (us == 0U) { return 1; }     /* 未初始化时，零延时也直接返回 */
    if (poll_clock_hz == 0U || poll_clock_hz != SystemCoreClock) { return 0; }
    while (us != 0U) {
        uint32_t chunk = us > 1000U ? 1000U : us;
        uint32_t cycles = (uint32_t)(((uint64_t)poll_clock_hz * chunk +
                                     999999U) / 1000000U);
        uint32_t start = DWT->CYCCNT;
        uint32_t previous = start;
        uint32_t stalled = 0U;
        for (;;) {
            uint32_t now = DWT->CYCCNT;
            if ((uint32_t)(now - start) >= cycles) { break; }
            if ((DWT->CTRL & DWT_CTRL_CYCCNTENA_Msk) == 0U) { return 0; }
            if (now == previous) {
                if (++stalled >= 1024U) { return 0; }
            } else {
                stalled = 0U;
                previous = now;
            }
        }
        us -= chunk;
    }
    return 1;
}
