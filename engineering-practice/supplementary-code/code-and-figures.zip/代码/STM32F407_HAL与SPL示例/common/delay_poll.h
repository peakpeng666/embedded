#ifndef COURSE_DELAY_POLL_H
#define COURSE_DELAY_POLL_H
#include <stdint.h>

/* 仅保证执行有限次循环，不保证微秒/毫秒精度；0 次立即返回。 */
void Delay_Loops(volatile uint32_t loops);

/* DWT 为可选扩展。返回 1 成功，0 表示计数器不可用或未初始化。
 * 不写 SysTick；变频后重新调用 Init；不用于 RTOS 或低功耗定时。
 */
int Delay_Poll_Init(void);
int Delay_Poll_us(uint32_t us);
#endif
