/* GPIO 寄存器对照，不是第三个 main，也不要与两套 GPIO_Init 同时调用。
 * PF9: 推挽输出；PE4: 上拉输入。适用 STM32F407。
 */
#include "stm32f4xx.h"

void GPIO_Register_Init_Example(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOFEN | RCC_AHB1ENR_GPIOEEN;
    (void)RCC->AHB1ENR;
#if defined(STM32F40_41xxx)
    GPIOF->BSRRL = (1U << 9);      /* 旧 SPL 头文件把 BSRR 分成两个 16 位成员 */
#else
    GPIOF->BSRR = (1UL << 9);
#endif
    GPIOF->OTYPER &= ~(1UL << 9);
    GPIOF->OSPEEDR &= ~(3UL << 18);
    GPIOF->PUPDR &= ~(3UL << 18);
    GPIOF->MODER = (GPIOF->MODER & ~(3UL << 18)) | (1UL << 18);
    GPIOE->MODER &= ~(3UL << 8);
    GPIOE->PUPDR = (GPIOE->PUPDR & ~(3UL << 8)) | (1UL << 8);
}

void GPIO_Register_Copy_Key_To_LED(void)
{
    uint32_t pressed = (GPIOE->IDR & (1UL << 4)) == 0U;
#if defined(STM32F40_41xxx)
    if (pressed) { GPIOF->BSRRH = (1U << 9); }
    else { GPIOF->BSRRL = (1U << 9); }
#else
    GPIOF->BSRR = pressed ? (1UL << (9 + 16)) : (1UL << 9);
#endif
}
