/* 仅供主机控制流单元测试，不可加入 STM32 工程。 */
#ifndef TEST_STM32F4XX_H
#define TEST_STM32F4XX_H
#include <stdint.h>
#define __FPU_PRESENT 0
#define __FPU_USED 0
#define HSI_VALUE 16000000U
#define HSE_VALUE 8000000U
#define FLASH_BASE 0x08000000U
#define RCC_CR_HSION 1U
#define RCC_CR_HSEON (1U << 16)
#define RCC_CR_HSEBYP (1U << 18)
#define RCC_CR_CSSON (1U << 19)
#define RCC_CR_PLLON (1U << 24)
#define RCC_CFGR_SWS (3U << 2)
#define RCC_CFGR_SWS_HSE (1U << 2)
#define RCC_CFGR_SWS_PLL (2U << 2)
#define RCC_PLLCFGR_PLLSRC_HSE (1U << 22)
#define CoreDebug_DEMCR_TRCENA_Msk (1U << 24)
#define DWT_CTRL_NOCYCCNT_Msk (1U << 25)
#define DWT_CTRL_CYCCNTENA_Msk 1U
struct Test_RCC { uint32_t CR, CFGR, PLLCFGR, CIR; };
struct Test_SCB { uint32_t CPACR, VTOR; };
struct Test_DWT { uint32_t CTRL, CYCCNT; };
struct Test_Debug { uint32_t DEMCR; };
extern struct Test_RCC test_rcc;
extern struct Test_SCB test_scb;
extern struct Test_Debug test_debug;
extern uint32_t SystemCoreClock;
struct Test_DWT *test_dwt_access(void);
void SystemCoreClockUpdate(void);
void SystemInit(void);
#define RCC (&test_rcc)
#define SCB (&test_scb)
#define CoreDebug (&test_debug)
#define DWT test_dwt_access()
#define __NOP() ((void)test_dwt_access())
#endif
