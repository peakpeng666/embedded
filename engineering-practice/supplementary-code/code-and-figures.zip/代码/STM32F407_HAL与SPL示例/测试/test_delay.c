#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "stm32f4xx.h"
#include "delay_poll.h"
uint32_t SystemCoreClock;
struct Test_Debug test_debug;
static struct Test_DWT counter;
static unsigned running, accesses;
void SystemCoreClockUpdate(void) {}
struct Test_DWT *test_dwt_access(void)
{
    ++accesses;
    if (running && (counter.CTRL & DWT_CTRL_CYCCNTENA_Msk) &&
        (test_debug.DEMCR & CoreDebug_DEMCR_TRCENA_Msk)) {
        counter.CYCCNT += 64U;
    }
    return &counter;
}
int main(void)
{
    Delay_Loops(0U); Delay_Loops(1U); Delay_Loops(100U);
    accesses = 0; assert(Delay_Poll_us(0U) == 1); assert(accesses == 0);
    assert(Delay_Poll_us(1U) == 0);
    SystemCoreClock = 0U; assert(Delay_Poll_Init() == 0);
    SystemCoreClock = 180000000U; assert(Delay_Poll_Init() == 0);
    SystemCoreClock = 168000000U;
    counter.CTRL = DWT_CTRL_NOCYCCNT_Msk; assert(Delay_Poll_Init() == 0);
    counter.CTRL = 0; running = 0; assert(Delay_Poll_Init() == 0);
    running = 1; assert(Delay_Poll_Init() == 1);
    assert(Delay_Poll_us(1U) == 1);
    assert(Delay_Poll_us(1000U) == 1);
    assert(Delay_Poll_us(2501U) == 1);
    counter.CYCCNT = UINT32_MAX - 100U; assert(Delay_Poll_us(10U) == 1);
    running = 0; accesses = 0; assert(Delay_Poll_us(1U) == 0);
    assert(accesses < 10000U); /* 停止的模拟计数器不会无限等待 */
    counter.CTRL = 0; assert(Delay_Poll_us(1U) == 0);
    SystemCoreClock = 84000000U; assert(Delay_Poll_us(1U) == 0);
    assert(Delay_Poll_us(0U) == 1);
    puts("delay: 17 assertion checks passed (host mock, not timing measurement)");
    return 0;
}
