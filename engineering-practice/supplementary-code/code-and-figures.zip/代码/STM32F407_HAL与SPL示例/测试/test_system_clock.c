#include <assert.h>
#include <stdio.h>
#include "stm32f4xx.h"
struct Test_RCC test_rcc;
struct Test_SCB test_scb;
static unsigned checks;
static void check(uint32_t expected)
{
    SystemCoreClockUpdate();
    assert(SystemCoreClock == expected);
    ++checks;
}
int main(void)
{
    static const uint32_t divs[16] = {1,1,1,1,1,1,1,1,2,4,8,16,64,128,256,512};
    unsigned i;
    SystemInit(); assert(test_scb.VTOR == FLASH_BASE);
    check(16000000U);
    test_rcc.CFGR = RCC_CFGR_SWS_HSE; check(8000000U);
    test_rcc.CFGR = RCC_CFGR_SWS_PLL;
    test_rcc.PLLCFGR = RCC_PLLCFGR_PLLSRC_HSE | (336U << 6) | 8U;
    check(168000000U);
    for (i=0;i<16;++i) {
        test_rcc.CFGR = RCC_CFGR_SWS_PLL | (i << 4);
        check(168000000U / divs[i]);
    }
    test_rcc.CFGR = RCC_CFGR_SWS_PLL;
    test_rcc.PLLCFGR |= (1U << 16); check(84000000U);
    test_rcc.PLLCFGR = (336U << 6) | 16U; check(168000000U);
    test_rcc.PLLCFGR = (336U << 6); check(0U);
    printf("clock: %u frequency cases passed; vector-base assertion passed (host mock)\n",checks);
    return 0;
}
