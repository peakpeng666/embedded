# STM32L4 本地实验与备份

2026-10-20 已在这台电脑上实际完成 USB 调试器识别、低速 SWD 连接、芯片信息读取、内部 Flash 备份和双向串口通信。

**当前开发板运行实验 1 的单灯验证版**：KEY0 用查询法启动七色轮闪，KEY1 用外部中断让灯全部熄灭；再按 KEY0 从红色重新开始。实测状态保存在实验目录的 `hardware_validation.json`。原 LCD / 温湿度演示保存在备份中，已实际恢复启动验证；恢复方式和完整资料见 [实验 1](lab1/README.md)。

| 项目 | 实测结果 |
| --- | --- |
| 板载调试器 | ATK-FS-CMSIS-DAP |
| 主控标识 | `DBGMCU_IDCODE = 0x20006461`，STM32L49x/L4Ax 系列；与照片中的 STM32L496VET6 相符 |
| 内核 | Cortex-M4，`CPUID = 0x410fc241` |
| 内部 Flash | 512 KiB |
| 读保护字段 | `0xAA`，读取内部 Flash 成功 |
| 最后一次运行状态检查 | 未停机、无锁死标志 |
| USB 串口 | `/dev/ttyACM0`；115200 / 8N1、无流控，双向通信通过 |
| 原程序交互 | `version` 返回 RT-Thread 4.0.1，构建日期 Dec 30 2024；`help` 返回命令列表和 `msh />` 提示符 |

前期连接排查没有烧录固件。随后经用户授权，实验 1 只擦写 `0x08010000–0x08010FFF` 两个应用页面；整片读回比对确认其他内容保持不变，选项字节未修改。程序使用 HSI16 时钟和板载按键/灯的 GPIO。回退试验恢复后的全部 512 KiB 与原备份一致，原演示成功启动；目前再次运行已验收的单灯实验。

## 直接使用串口

保持 USB 线接在板上的 **USB_COM** 接口，两只 USART1 跳线分别连接 **PA9(T) ↔ RXD**、**PA10(R) ↔ TXD**。

在终端执行：

```bash
/home/peakpeng/Desktop/Test/tools/console.sh
```

当前实验固件输入 `status` 或 `help`。恢复原演示后，按回车显示 `msh />`，输入 `version` 或 `help`。按 **Ctrl+]** 退出。启动脚本使用稳定的设备标识，不依赖 `ttyACM0` 的编号；重新插 USB 后若需要临时访问权限，会通过 sudo 提示输入本机密码，不保存密码。

恢复原演示后，可自动检查它的版本回复：

```bash
cd /home/peakpeng/Desktop/Test
.venv/bin/python tools/check_serial.py
```

该检查只发送空行和 `version` 命令。使用前先关闭其他串口终端。

## 本次故障定位

- 初始测试中，电脑发送空行会触发主控接收活动，但主控发送的固定文字无法回到电脑。
- 断电重新插接后，主控发送的 `UART_PATH_TEST` 能完整收到；此时电脑到主控的输入方向仍不通。
- 再次断电互换两只 USART1 跳线帽并接回 USB_COM 后，`version` 和 `help` 均正常回复，分别收到 147 字节和 2871 字节。

结果支持 USART1 跳线连接或接触问题；目前不能单独认定某一只跳线帽损坏。保持当前接法即可，后续调整跳线前先断电。

## 已有程序读取温湿度

2026-10-20 16:18（日本时间），使用现有 RT-Thread 命令完成 AHT10 基础读取验证：

```text
aht10 probe i2c2
aht10 read
```

首次返回 0.0% / -50.0°C，判为无效；复读后恢复正常。随后连续五次读数为：

| 次数 | 温度 / °C | 相对湿度 / % |
| --- | --- | --- |
| 1 | 31.7 | 29.0 |
| 2 | 31.6 | 30.4 |
| 3 | 31.6 | 30.5 |
| 4 | 31.6 | 30.6 |
| 5 | 31.6 | 30.8 |

传感器能返回变化且在合理范围内的数据，基础通信/读取通过；未用参考温湿度计校准精度。首次异常原因未进一步证实。日志：`logs/aht10_validation_20261020T161816+0900.json`。这些是原程序的历史验证结果；当前单灯固件不含温湿度功能。

实验 1 的代码、电路、实板结果和回退命令见 [lab1/README.md](lab1/README.md)。用户明确选择只用一个灯验证；没有把这一版作为 2～8 颗独立 LED 的实物验收。

## 重新检查

在终端执行：

```bash
cd /home/peakpeng/Desktop/Test
python3 tools/board_access.py --check
.venv/bin/python tools/inspect_board.py
```

如果拔插 USB 后失去访问权限，再执行：

```bash
sudo python3 tools/board_access.py
```

这个脚本只对准确匹配的 ATK 设备节点授予当前用户临时访问权限，不修改用户组或安装永久 udev 规则。它不保存密码。

`inspect_board.py` 固定以 100 kHz SWD 读取已知地址。它不初始化 CPU 调试目标，不暂停或复位主控，不装载 Flash 算法，不执行目标内存写入。通信过程中会配置调试接口自身的 DP/AP 控制寄存器，结束时释放调试连接。

只监听已有串口输出：

```bash
.venv/bin/python tools/listen_serial.py --seconds 10
```

再次备份内部 Flash：

```bash
.venv/bin/python tools/inspect_board.py --backup
```

## 已保存文件

- 内部 Flash 备份：`backups/stm32l4_internal_flash_20261020T154711+0900.bin`
- 大小：524288 字节。
- SHA-256：`18b55e23284658dd10fe83259900c99e0479a75a3094362e85b7939ecc05fc3d`
- 最后一次芯片检查：`logs/chip_20261020T163002+0900.json`
- 单灯写入与全片比对：`logs/lab1_apply_20261020T172350+0900.json`
- 实际回退验证：`logs/lab1_restore_20261020T170220+0900.json`
- 单灯实板结果：`lab1/hardware_validation.json`
- 串口版本验证：`logs/serial_check_20261020T161248+0900.json`，`verified: true`。
- 串口帮助验证：`logs/serial_help_20261020T161250+0900.json`，`verified: true`。
- 工具依赖：`tools/requirements.txt`，实际安装于项目 `.venv` 中。

备份覆盖内部 Flash，包括其中的引导程序和应用程序；不包括外部 SPI Flash、选项字节或外设存储。已将本次改动的两个页面恢复，并验证全片与原备份逐字节一致、原程序成功启动。其他页面无需擦写。

ARM 编译器和对应芯片设备包位于项目 `.toolchains/`，没有安装到系统目录。七色轮闪与中断灭灯程序已编译，六组电脑端逻辑测试通过；实板结果见 `lab1/hardware_validation.json`。

## 硬件摆放

保持单根 USB 供电，裸板放在绝缘、干燥表面。调整跳线或外接线路前先断电。

## 参考

- [ST STM32L496 数据手册](https://www.st.com/resource/en/datasheet/stm32l496ve.pdf)
- [ST 官方寄存器地址定义](https://github.com/STMicroelectronics/cmsis-device-l4/blob/master/Include/stm32l496xx.h)
- [pyOCD 连接选项](https://pyocd.io/docs/options.html)
- [pyOCD 安装说明](https://pyocd.io/docs/installing.html)
