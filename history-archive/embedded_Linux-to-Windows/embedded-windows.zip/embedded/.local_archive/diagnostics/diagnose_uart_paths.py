#!/usr/bin/env python3
"""Test existing USART1 paths without halting, resetting, or flashing the MCU.

The only target writes are USART1 ICR.IDLECF and a short marker to USART1 TDR.
Clocks, GPIO, UART configuration, RAM, flash, and option bytes are untouched.
"""

from datetime import datetime
import json
import time

import serial
from serial.tools import list_ports
from pyocd.core.helpers import ConnectHelper
from pyocd.coresight.ap import AccessPort, APv1Address
from pyocd.coresight.dap import DP_CTRL_STAT, MASKLANE, TRNNORMAL
from pyocd.probe.debug_probe import DebugProbe

from inspect_board import ROOT, PROBE_ID


USART1 = 0x40013800
IDLE = 1 << 4
TXE = 1 << 7
MARKER = b"\r\nUART_PATH_TEST\r\n"


def main():
    stamp = datetime.now().astimezone().strftime("%Y%m%dT%H%M%S%z")
    result = {"time": stamp, "marker": MARKER.decode("ascii")}
    ports = [
        p for p in list_ports.comports()
        if (p.vid, p.pid, p.serial_number) == (0x04D8, 0x00DF, PROBE_ID)
    ]
    if len(ports) != 1:
        raise RuntimeError(f"Expected one ATK serial port, found {len(ports)}.")
    session = ConnectHelper.session_with_chosen_probe(
        unique_id=PROBE_ID, blocking=False, auto_open=False, no_config=True,
        target_override="cortex_m", frequency=100_000, connect_mode="attach",
        auto_unlock=False, resume_on_disconnect=False,
        **{"pack.debug_sequences.enable": False, "user_script": "/dev/null"},
    )
    if session is None:
        raise RuntimeError("Expected debug probe was not found.")
    dp = session.target.dp
    connected = False
    port = serial.Serial(
        port=None, baudrate=115200, timeout=0.05, write_timeout=1,
        xonxoff=False, rtscts=False, dsrdtr=False, exclusive=True,
    )
    port.port = ports[0].device

    def capture(seconds):
        data = bytearray()
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            data.extend(port.read(4096))
        return {"bytes": len(data), "hex": data.hex(), "text": data.decode("utf-8", "replace")}

    try:
        port.open()
        session.open(init_board=False)
        dp.connect(DebugProbe.Protocol.SWD)
        connected = True
        ap = AccessPort.create(dp, APv1Address(0))
        if ap.read32(0xE0042000) & 0xFFF != 0x461:
            raise RuntimeError("Unexpected MCU; no peripheral writes performed.")
        core = ap.read32(0xE000EDF0)
        if core & ((1 << 17) | (1 << 19)):
            raise RuntimeError("MCU is halted or locked up; stopping.")
        before = [ap.read32(USART1 + offset) for offset in (0, 4, 8, 12)]
        result["config_before"] = [f"0x{v:08x}" for v in before]
        # Require the previously inspected 115200/8N1 full-duplex setup.
        if before != [0x2D, 0, 0, 0x2B6]:
            raise RuntimeError("UART configuration changed; stopping before writes.")
        result["baseline_capture"] = capture(0.25)

        ap.write32(USART1 + 0x20, IDLE)
        dp.flush()
        result["isr_idle_cleared"] = f"0x{ap.read32(USART1 + 0x1C):08x}"
        time.sleep(0.25)
        result["idle_without_host_traffic"] = bool(ap.read32(USART1 + 0x1C) & IDLE)
        result["host_bytes_sent"] = port.write(b"\r\n")
        port.flush()
        result["after_host_capture"] = capture(0.5)
        result["isr_after_host"] = f"0x{ap.read32(USART1 + 0x1C):08x}"

        ap.write32(USART1 + 0x20, IDLE)
        dp.flush()
        result["mcu_bytes_sent"] = 0
        for byte in MARKER:
            deadline = time.monotonic() + 0.5
            while not (ap.read32(USART1 + 0x1C) & TXE):
                if time.monotonic() >= deadline:
                    raise RuntimeError("UART TX buffer stayed busy; stopping.")
            ap.write32(USART1 + 0x28, byte)
            dp.flush()
            result["mcu_bytes_sent"] += 1
        result["after_mcu_capture"] = capture(1.0)
        result["isr_after_mcu"] = f"0x{ap.read32(USART1 + 0x1C):08x}"
        after = [ap.read32(USART1 + offset) for offset in (0, 4, 8, 12)]
        result["config_unchanged"] = before == after
        final_core = ap.read32(0xE000EDF0)
        result["core_halted"] = bool(final_core & (1 << 17))
        result["core_lockup"] = bool(final_core & (1 << 19))
        result["status"] = "completed"
    except Exception as error:
        result["status"] = "failed"
        result["error"] = str(error)
        raise
    finally:
        try:
            if connected:
                result["debug_power_acknowledged_off"] = dp.power_down_debug()
                dp.write_reg(DP_CTRL_STAT, MASKLANE | TRNNORMAL)
                dp.flush()
                result["debug_power_request_bits_clear"] = not bool(
                    dp.read_reg(DP_CTRL_STAT) & 0x50000000
                )
        finally:
            session.close()
            port.close()
            destination = ROOT / "logs" / f"uart_paths_{stamp}.json"
            destination.parent.mkdir(exist_ok=True)
            destination.write_text(json.dumps(result, indent=2) + "\n")
            print(json.dumps(result, indent=2), flush=True)
            print(f"Report: {destination}", flush=True)


if __name__ == "__main__":
    main()
