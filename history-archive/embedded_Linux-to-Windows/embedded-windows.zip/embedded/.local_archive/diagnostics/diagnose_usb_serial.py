#!/usr/bin/env python3
"""Test ATK CDC serial directly through USB, then restore the kernel driver.

Temporarily claims only CDC interfaces 0 and 1. Does not configure the MCU,
reset it, or program any firmware. Sends only a blank line to the UART.
"""

from datetime import datetime
from pathlib import Path
import struct
import time

import libusb_package
import usb.core
import usb.util


def main():
    devices = [
        dev for dev in libusb_package.find(find_all=True, idVendor=0x04D8, idProduct=0x00DF)
        if dev.serial_number == "ATK-03262021"
    ]
    if len(devices) != 1:
        raise RuntimeError(f"Expected exactly one ATK device, found {len(devices)}.")
    dev = devices[0]
    previous = {i: dev.is_kernel_driver_active(i) for i in (0, 1)}
    claimed = []
    received = bytearray()
    try:
        for interface in (0, 1):
            if dev.is_kernel_driver_active(interface):
                dev.detach_kernel_driver(interface)
        for interface in (0, 1):
            usb.util.claim_interface(dev, interface)
            claimed.append(interface)

        coding = struct.pack("<IBBB", 115200, 0, 0, 8)
        dev.ctrl_transfer(0x21, 0x20, 0, 0, coding, timeout=1000)
        dev.ctrl_transfer(0x21, 0x22, 3, 0, b"", timeout=1000)
        try:
            reported = bytes(dev.ctrl_transfer(0xA1, 0x21, 0, 0, 7, timeout=1000))
            print("CDC line coding:", reported.hex(), flush=True)
            if len(reported) == 7:
                print("Baud / stop / parity / bits:", struct.unpack("<IBBB", reported), flush=True)
        except usb.core.USBError as error:
            print(f"GET_LINE_CODING: {error}", flush=True)

        time.sleep(0.3)
        print("USB OUT bytes:", dev.write(0x03, b"\r\n", timeout=1000), flush=True)
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            try:
                packet = bytes(dev.read(0x83, 4096, timeout=300))
                received.extend(packet)
                print("USB IN:", repr(packet), flush=True)
            except usb.core.USBTimeoutError:
                pass
    finally:
        for interface in reversed(claimed):
            usb.util.release_interface(dev, interface)
        for interface, active in previous.items():
            if active and not dev.is_kernel_driver_active(interface):
                dev.attach_kernel_driver(interface)
        usb.util.dispose_resources(dev)
        stamp = datetime.now().astimezone().strftime("%Y%m%dT%H%M%S%z")
        log = Path(__file__).resolve().parents[1] / "logs" / f"raw_usb_serial_{stamp}.bin"
        log.write_bytes(received)
        print(f"Received {len(received)} bytes; kernel CDC driver restored. Log: {log}", flush=True)


if __name__ == "__main__":
    main()
