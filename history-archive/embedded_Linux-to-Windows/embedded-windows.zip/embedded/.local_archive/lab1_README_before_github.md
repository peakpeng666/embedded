# 实验 1：查询与外部中断——单灯验证

## 已确认的范围

原题要求两个按键分别使用查询法、外部中断，控制 2～8 个 LED 的不同闪烁组合。用户现有开发板只有一颗 RGB 灯，并明确选择“只用一个灯验证”。因此本版使用一颗 RGB 灯显示七种基本颜色组合，以查询键启动轮闪、中断键灭灯来验证控制逻辑；不把一个 RGB 封装算作多颗独立 LED 的实物验收。

七色轮闪与中断灭灯版已编译通过。当前版本的写入比对与实板结果见 `hardware_validation.json`；旧红灯慢闪/快闪版的记录保存在 `releases/lab1_single_red_validation.json`。实际回退已经验证：恢复原备份后全部 512 KiB 一致，原 RT-Thread 4.0.1 正常启动。

## 操作

| 操作 | 检测方式 | 灯光现象 |
| --- | --- | --- |
| 上电或复位 | 初始化 | 三路熄灭，等待按键 |
| 按 KEY0 | 主循环每 5 ms 查询 PD10 | 红、绿、蓝、黄、青、紫/品红、白轮流闪烁 |
| 按 KEY1 | PD9 / EXTI9 外部中断 | 消抖确认后全部熄灭，保持停止 |
| 松开 KEY1，再按 KEY0 | 查询法 | 从红色重新开始 |
| 长按任意一键 | 20 ms 消抖、松开后重触发 | 每次按下只登记一次 |

每种颜色亮 300 ms、随后熄灭 300 ms。完整一轮为 14 帧、4.2 秒。数字 RGB 的七种基本点亮组合为 R、G、B、R+G（黄）、G+B（青）、R+B（紫/品红）、R+G+B（白）。本版的“所有颜色”指这七种基本组合。

再次按 KEY0 会从红色重新开始；KEY1 不是暂停并保持当前灯色，而是全部关闭。按住 KEY1 时 KEY0 不能启动，松开 KEY1 也不会自动亮灯，需重新按 KEY0。上电时已按住的键须先松开再按。

**中断的含义**：外设事件使 CPU 转去执行相应处理程序，处理结束后继续原来的工作。“灭灯”是本实验指定的处理动作；中断本身并不规定灯必须停住或熄灭。本版在 20 ms 消抖确认后执行灭灯，不等待正在播放的灯序结束。

串口为 115200 / 8N1，无流控：`status` 返回 OFF/COLOR 模式和计数，`help` 返回操作说明。每次有效按下输出 `KEY0 POLL` 或 `KEY1 EXTI`。

## 接线与实现

| 资源 | MCU 引脚 | 配置 |
| --- | --- | --- |
| 红色通道 | PE7 | 共阳 RGB，经板载 R38 1 kΩ，低电平亮 |
| 绿色、蓝色通道 | PE8、PE9 | 参与七色组合；低电平亮，各有板载限流电阻 |
| KEY0 | PD10 | 低有效，板载 10 kΩ 上拉；EXTI10 禁用，只查询 |
| KEY1 | PD9 | 低有效，板载 10 kΩ 上拉；EXTI9 检测按下和松开边沿 |
| USART1 | PA9 / PA10 | AF7；保持 PA9(T) ↔ RXD、PA10(R) ↔ TXD |

保持 USB_COM 接口和现有跳线，不需外接电路。LED 输出先预置高电平再启用输出，避免初始化误亮。内部 HSI16 提供 16 MHz 时钟，SysTick 每 1 ms 计时。

KEY1 ISR 只清挂起位、记录电平、时刻和边沿次数，不做延时或串口打印。主循环复制中断记录并消抖；没有 EXTI 事件不能仅凭电平变化生成 KEY1 动作。KEY0 由主循环定时查询。灯序使用时间差推进，闪烁过程中仍响应按键。

USART RX 采用主循环轮询，所以主循环不会等待 1 ms 的 WFI 唤醒；115200 波特率下相邻字符约 87 µs。串口发送使用队列，`tx_dropped` 用于发现日志拥塞。

## 代码、编译和离线测试

- `src/main.c`：GPIO、EXTI、SysTick、串口和主循环。
- `src/lab_logic.c`：消抖、七色灯序、启动与灭灯。
- `src/startup.S`：中断向量和启动；EXTI9_5 的 IRQ 编号为 23。
- `stm32l496_app.ld`：Flash 从 `0x08010000` 开始；只使用前 64 KiB SRAM。
- `tests/test_logic.c`：六组行为测试；涵盖长按、抖动、七种颜色与暗间隔、IRQ 停灯依赖、停止键优先、计时回绕等。

```bash
cd /home/peakpeng/Desktop/Test
make -C lab1 all test
.venv/bin/python lab1/verify_image.py
```

GCC Arm 10.3.1 与 ST/Arm CMSIS 头文件均已准备在本地，源码采用 `-Wall -Wextra -Werror`；电脑端六组测试同时启用 AddressSanitizer 和 UndefinedBehaviorSanitizer。记录：`../logs/lab1_build.log`。

当前单灯镜像 `build/lab1.bin` 为 2724 字节，SHA-256：

`231683d50a998b4049ab6d5d939e86cf33b15599c28d222b3fb2cdfc777cec27`

`build/lab1.hex` 含明确地址，`build/lab1.elf` 含调试信息。`build/validation.json` 只表示离线镜像验证；实板结果独立保存在 `hardware_validation.json`，避免重新编译覆盖实测记录。

## 写入与回退

实际只擦写 `0x08010000–0x08010FFF` 两个 2 KiB 页面；新镜像后方的原页面内容按备份保留。前 64 KiB 引导区、两页以外内容及选项寄存器均已比对不变。

原始 512 KiB 备份：`../backups/stm32l4_internal_flash_20261020T154711+0900.bin`。

原始 SHA-256：`18b55e23284658dd10fe83259900c99e0479a75a3094362e85b7939ecc05fc3d`。

局部回退文件：`../backups/lab1_original_pages_08010000_4096.bin`。它包括本次涉及的两个页面。回退工具使用固定镜像、固定地址和固定校验值，禁用整片擦除及自动解除保护；设备包已保存于 `.toolchains/`。

恢复原 LCD / 温湿度演示的命令：

```bash
cd /home/peakpeng/Desktop/Test
.venv/bin/python tools/lab1_flash.py restore
```

该命令会真实写入两个应用页面；先关闭其他串口终端并保持 USB 连接。用户已授权且已实测的回退记录：`../logs/lab1_restore_20261020T170220+0900.json`。原程序启动日志中的 OTA 应用头校验提示，在完整恢复原备份后也存在；原应用仍成功启动，本次未修改引导程序处理该提示。

当前单灯写入记录：`../logs/lab1_apply_20261020T172350+0900.json`。需要重复写入这个固定版本时可使用 `tools/lab1_flash.py apply`；工具不会自动采纳后续重新编译的任意固件。Makefile 本身没有烧录目标。

## 资料与验收边界

最小系统图、单灯电路图及验证记录：`../output/pdf/lab1_design.pdf`。最小系统图是实验功能示意，不要求改动现板或补焊元件。

引脚与电阻值参考原厂 V2.4 图的公开镜像 `references/Pandora_STM32L4_Board_V2.4_SCH.pdf`；该图标注 STM32L475/ST-Link，实际板为 STM32L496/CMSIS-DAP。编译与烧录均选 STM32L496，KEY0 / KEY1 和红灯的对应关系此前已确认；七色效果以本版实板验收记录为准。

本版不含原应用的 LCD、温湿度或 Wi-Fi 功能。恢复原演示可使用上述回退流程。若后续完成原题的 2～8 颗独立 LED 部分，需要增加每颗独立限流的 LED 电路，并重新核对 GPIO 分配与实测灯序。

参考：[ST 数据手册](https://www.st.com/resource/en/datasheet/stm32l496ve.pdf)、[ST CMSIS 定义](https://github.com/STMicroelectronics/cmsis-device-l4/blob/master/Include/stm32l496xx.h)、[Keil 设备包](https://www.keil.arm.com/packs/stm32l4xx_dfp-keil/versions/)、[V2.4 原图公开镜像](https://github.com/TrekMax/Pandora_STM32L475_Zephyr/tree/main_v3.4/docs/Hardware)。
