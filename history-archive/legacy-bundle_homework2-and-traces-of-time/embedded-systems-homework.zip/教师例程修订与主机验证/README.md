# 教师例程修订与可复现检查

这是课程原工程的独立修订副本，原件未修改。初次修订日期：2026-10-04；本次启动输出、配置与应用回归复核：2026-10-06。

**验证级别：主机侧逻辑测试、应用源码节选回归、数学模型、主机GCC语法检查。未完成AC5目标编译、链接、CubeMX重新生成、MCU仿真、烧录或板测。**

## 先选择正确硬件，不能按芯片型号直接互换

| 目录 | 原件 | 所需晶振与引脚 | 改动 |
|---|---|---|---|
| teacher_hal | CH5EX01HAL | 原源码要求HSE8MHz；PE3/PE4 LED，PB0–PB7流水灯 | Q4→Q7；流水每100ms一步，每5步翻转PE3，完整周期名义1Hz；PB0–PB7先置高再启用输出 |
| teacher_hal02 | CH5EX02HAL | 原源码要求HSE8MHz；PF6低有效按键，PE3/PE4 LED | Q4→Q7；20ms稳定按下沿计数，稳定释放后再允许计数 |
| teacher_spl02 | CH5Ex02STD | 实际生效源码为HSE8MHz、M8；PF6低有效按键，PE3/PE4 LED | 保留8MHz/M8，修复按键采样与长按重复计数，并纠正旧时钟注释；PE3/PE4先置高再启用输出 |

这些不是普中PF9/PE4按键接法。三个修订工程的实际配置都以HSE8MHz为前提；teacher_spl02原件本来就是HSE_VALUE=8000000、PLL_M=8，没有改变其时钟源码。CH5Ex01STD单独原件才是25MHz/M25，不能把01的配置套到02。原模板头注和开发模板说明中的25MHz是历史默认说明，不代表当前生效配置。软件声明不是晶振实测值，使用前仍须核对原理图与晶振；25MHz输入不可套用本包M8配置。

题干要求PE3心跳1Hz、PB0–7顺序流水，未限定流水步长。本修订选择100ms流水步长并每5步翻转PE3，以靠近原STD示例教学节拍；这是一项明确选择，不是新增题干要求。HAL_Delay与执行开销意味着“1Hz”是名义值，不是板测精度。

## 文件用途

- verified_projects/：完整独立源工程副本，保留原库与原工程结构；旧AXF/HEX/对象/构建日志未带入，避免误认为是修订后产物
- replacements/：仅变更文件，便于对照
- patches/：统一diff，方便人工评审
- revision_manifest.json：适用硬件、原源码哈希、变更前后哈希、每项原因
- apply_revision.py：从匹配的原工程创建新副本，不覆盖原目录；输入不匹配则停止
- tests/key_filter.h：与两个按键工程实际使用的逻辑一致，已进行主机C测试
- run_checks.py：可重复的主机测试及可选语法检查；指定--projects后也运行应用回归
- tests/project_clock_config.py：从实际Keil项目、include路径及C源码提取有效时钟参数；用于配置一致性检查，仍不是ARM编译或PLL仿真
- tests/run_application_checks.py：直接提取三个工程的循环体与GPIO初始化函数，在主机替身环境检查启动状态、流水顺序、心跳步数和按键到LED状态的对应；不执行时钟配置或芯片初始化
- tests/run_coverage_checks.py：在临时副本中故意改变LED方向、移除按键上拉或GPIO时钟、把STD的HSE常量改成25MHz，验证检查能够检出这些错误；不会修改待验工程
- plot_models.py：可重复计算图，使用matplotlib（可选，原环境已有）
- results/：实际检查日志、JSON结果、CSV合成按键轨迹和PNG/SVG计算图

## 如何复核与应用

直接使用verified_projects中的对应工程；它们仍需在原有Keil/AC5环境执行Rebuild。

若从自己保存的原RAR重建：先解压RAR，使source路径下面直接出现Core/Drivers或UserMain/STM32F4xx_Startup等原始目录，再执行：

```text
python apply_revision.py teacher_hal 原始CH5EX01HAL解包目录 全新目标目录
python apply_revision.py teacher_hal02 原始CH5EX02HAL解包目录 全新目标目录
python apply_revision.py teacher_spl02 原始CH5Ex02STD解包目录 全新目标目录
```

脚本核对全部原C/H/汇编/IOC/uvprojx/uvoptx SHA-256；不匹配时不要强行跳过校验，应先确认版本。目标目录必须不存在且不能位于源目录内部。此脚本不执行任何工程文件，也不调用Keil。

主机检查（Python3 + 主机GCC；没有安装新工具）：

```text
python run_checks.py
python run_checks.py --projects verified_projects
python plot_models.py
```

第三条需要matplotlib；前两条只需要Python标准库和GCC。主机可执行程序由本包测试源码及明确节选的应用代码现编译生成，运行后删除，不执行用户上传二进制。应用回归另使用GCC自带的未定义行为与数组边界检测；无需新装工具。

## 已实际完成的检查

1. key_filter C逻辑在主机GCC C99、-Wall -Wextra -Werror -pedantic下编译并运行：释放、短毛刺、按下抖动、长按、释放抖动、第二次按下、32位tick回绕、启动时已按住全部通过
2. 1401个合成采样点输入同一C状态机，事件在136ms与920ms各一次；长按不反复计数。CSV与图保留输入、稳定状态和事件，非真实开关采集
3. 三个main源文件和两个HAL gpio.c用原工程头文件执行主机gcc -fsyntax-only，五项退出码均0；仍有64位主机/32位MCU指针宽度相关警告，日志完整保留。STD原始include的usermain.h与文件Usermain.h大小写差异，用临时头文件别名支持Linux检查，未修改Windows项目文件
4. 从每个uvprojx的目标宏和include路径预处理读取HSE_VALUE；STD读取生效PLL宏，HAL读取main中PLL配置并解析真实头文件常量，再与修订清单和IOC逐项比对。三个工程均为8MHz/M8/N336/P2/Q7。检查PLL输入、VCO、系统及Q支路边界；25MHz错误输入配M8时输入3.125MHz超限，525MHz仅理想代数结果，不保证锁定。另复核SysTick LOAD+1
5. 原件全部源码哈希未变，三个完整副本变更文件与replacement哈希一致
6. 实际应用循环体与GPIO初始化函数的节选回归：HAL流水70000步保持PB0–PB7顺序、每5步翻转PE3且不影响PE4；两个按键版本各300次按压，四种LED输出顺序、毛刺、抖动、长按、短暂释放、再次按下、启动按住、32位tick回绕和不等间隔采样全部通过。GPIO/延时/时间输入使用明确替身；新增记录GPIO时钟使能、方向和按键上拉，并在初始化后检查PE3/PE4、PB0–PB7输出和PF6上拉输入。未执行芯片启动、时钟配置或真实中断
7. 针对本次新增的启动输出要求，同一回归在10月5日基线中检出HAL PB0–PB7初始全低，以及STD在置高前启用输出；修订后全部通过。基线失败与修订后通过的日志均保留

**语法检查不验证汇编、ARM ABI、库链接、AC5兼容性、硬件时序或外设。不能据此写“修订工程已编译通过/仿真通过”。**

## 启动时先预置LED熄灭电平

教师例5-1和例5-2的LED均为低电平点亮。HAL流水灯原gpio.c先把PB0–PB7写低，随后main先执行HAL_Delay(100)，因此源码上存在第一步前八灯同时点亮的状态。本次将初始值改为高，并同步IOC中八个引脚的PinState字段；第一次流水步进仍由原循环控制。

STD按键版本原先先启用PE3/PE4输出，再用GPIO_SetBits熄灯。RM0090 Rev19第283页规定ODR复位值为0，所以现在在使能GPIO时钟之后、开启输出模式之前先预置高电平。这样消除程序主动配置输出时的低电平窗口；它不能保证电源上升、复位默认引脚状态或外部电路的所有瞬态。这里是源码推导与主机顺序检查，没有声称看到实板闪光或测得脉宽。

这些是启动行为的稳健性改进，不把“启动全灭”额外宣称为例5-1题干的明确要求。例5-2本身明确要求上电后两灯熄灭。

## 按键行为设计

- 每轮重新读取PF6，原来的“延时后再判断旧值”已去掉
- 候选电平连续稳定至少20ms才被接受；只在稳定高→低时计一次
- 长按不重复；稳定释放后重新使能下一次按下
- 上电默认视为释放；若上电已按住，稳定20ms后计一次
- 20ms是教学设计值；小于该稳定窗口的脉冲不会产生按键事件，实际开关仍应实测调整
- 状态机本身非阻塞，主循环仍沿用原例程HAL_Delay(1)/Delay(1)让步；这不是RTOS方案，名义采样间隔不代表严格1ms
- HAL用HAL_GetTick；STD沿用原1ms SysTick_Handler→TimingDelay_Decrement，在此增加单一volatile毫秒计数，无新中断框架

## 重新生成与构建注意

保留的原始CubeMX配置报告属于教师旧配置，未伪造生成新版报告；报告中的旧Q4等设置须与修订说明对照。

HAL .ioc的PLLQ字段、IPParameters、48MHz计算显示已同步；流水版本PB0–PB7的初始PinState也已同步为GPIO_PIN_SET；Cortex_Div显示改为实际默认HAL时基使用的HCLK。没有运行CubeMX重新生成，IOC可被新版本生成器规范化，须在使用者现有环境再次核对。

CubeMX重新生成前保持代码在USER CODE区；key_filter.h为手写头文件。生成后应再次核main的Q7、时间片、PF6采样与按键helper引用，不能只看图形时钟树。

Keil中打开：
- teacher_hal/CH5EX01HAL/MDK-ARM/CH5EX01HAL.uvprojx
- teacher_hal02/CH5EX02HAL/MDK-ARM/CH5EX02HAL.uvprojx
- teacher_spl02/UserMain/CH5Ex02STD.uvprojx

使用原例程AC5编译器和已安装器件包，保存新的完整Rebuild日志。未经新的日志不能沿用教师原HAL3390或STD1528等代码尺寸作为修订证据。无实体板时可以如实保留构建/仿真受阻记录，不编造GPIO或时钟现象。

## 来源与电气依据

- [CH5EX01HAL原RAR](https://drive.google.com/file/d/1SiaXWNtQBBjrw8Dl70PK68exQ3V929ve/view)
- [CH5EX02HAL原RAR](https://drive.google.com/file/d/1eYPEfxzdqma7slRJ-QxE6-TVGpuicq_G/view)
- [CH5Ex02STD原RAR](https://drive.google.com/file/d/1_Eqqedya6NRjtd38yxUHLNh2EwDwJ3xX/view)
- 原始源工程的厂商版权/许可文字保持原样
- ST DS8626 Rev12表36：PLL输入0.95–2.10MHz，PLL48支路最大75MHz；Q7使336MHz/7=48MHz。实际供电与Flash等待周期也必须符合器件要求

所有图均为教育计算/合成输入，不是示波器图、真实寄存器仿真或硬件测试结果。

## 2026-10-06 再复核勘误

此前误将CH5Ex01STD的25MHz/M25说明套用到teacher_spl02。现依据该工程自己的uvprojx、HSE_VALUE和PLL宏改正README、应用注释、清单及计算图；不改已正确的HSE8/M8时钟源码。旧通用模板注释保持原样，阅读时以预处理后的生效配置为准。

原应用测试只观察输出锁存替身，故意把LED改为输入仍可通过。新增GPIO时钟、方向和PF6上拉检查后，这两类错误会被检出；原始测试的变异通过和新版测试的变异失败均单独保留。这些增强仍不包含真实GPIO电压、复位瞬态、HAL延时耗时、SysTick中断投递、目标链接或Keil/AC5执行。
