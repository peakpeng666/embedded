#!/usr/bin/env python3
"""Create a NEW teacher-project copy from exact original sources.
Usage: python apply_revision.py teacher_hal /path/to/unpacked/source /path/to/new/copy
Does not execute project code, run Keil, modify originals, or select hardware.
"""
from pathlib import Path
import argparse,hashlib,json,shutil,sys
base=Path(__file__).resolve().parent
m=json.loads((base/'revision_manifest.json').read_text(encoding='utf-8'))
a=argparse.ArgumentParser(description=__doc__)
a.add_argument('profile',choices=m['profiles']);a.add_argument('source',type=Path);a.add_argument('destination',type=Path)
a=a.parse_args();src=a.source.resolve();dst=a.destination.resolve()
if not src.is_dir():sys.exit('Source directory does not exist')
if dst.exists() or dst==src or src in dst.parents:sys.exit('Destination must be NEW and outside source tree')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
# Validate exact original source/config snapshots, including unchanged clock and pin definitions.
for name,expected in m['source_hashes'][a.profile].items():
    p=src/name
    if not p.is_file() or sha(p)!=expected:sys.exit('Original source mismatch: '+name)
for f in m['profiles'][a.profile]:
    original=src/f['path'];replacement=base/'replacements'/a.profile/f['path']
    if f['before_sha256'] is None and original.exists():sys.exit('Unexpected existing new file: '+f['path'])
    if sha(replacement)!=f['after_sha256']:sys.exit('Replacement digest mismatch: '+f['path'])
# Do not carry old compiler outputs into a revision presented for fresh rebuild.
def ignore(directory,names):
    derived={'.o','.axf','.hex','.map','.d','.crf','.lnp','.tra','.iex','.htm','.dep','.bak'}
    return [n for n in names if Path(n).suffix.lower() in derived or '.uvguix.' in n]
shutil.copytree(src,dst,ignore=ignore)
for f in m['profiles'][a.profile]:
    p=dst/f['path'];p.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(base/'replacements'/a.profile/f['path'],p)
    assert sha(p)==f['after_sha256']
(dst/'REVISION_STATUS.txt').write_text('Revised educational source copy. Original preserved.\nNo MCU build, CubeMX regeneration, simulator pass or board test performed by this script.\nHardware/crystal: '+m['hardware'][a.profile]+'\nRebuild with the original Keil/AC5 toolchain before any use. Verify wiring before flashing.\n',encoding='utf-8')
print('Created:',dst);print('Profile:',a.profile);print('Verified original sources and replacement SHA-256; fresh target rebuild still required.')
