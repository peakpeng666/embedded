#ifndef KEY_FILTER_H
#define KEY_FILTER_H
#include <stdint.h>
/* Active-low key, sampled regularly. Stable press emits exactly one event.
 * Stable release rearms it. Startup assumes released; holding at startup
 * produces one event after 20 ms. Unsigned elapsed arithmetic tolerates wrap. */
typedef struct {
    uint32_t changed_at;
    uint8_t candidate;
    uint8_t stable;
} KeyFilter;
#define KEY_FILTER_INITIALIZER {0U, 1U, 1U}
static uint8_t KeyFilter_Update(KeyFilter *key, uint8_t raw, uint32_t now)
{
    raw = (raw != 0U) ? 1U : 0U;
    if (raw != key->candidate) {
        key->candidate = raw;
        key->changed_at = now;
    }
    if (key->stable != key->candidate &&
        (uint32_t)(now - key->changed_at) >= 20U) {
        key->stable = key->candidate;
        return (key->stable == 0U) ? 1U : 0U;
    }
    return 0U;
}
#endif
