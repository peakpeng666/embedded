/**
  ******************************************************************************
  * 模板（基于STM32F4xx_DSP_StdPeriph_Lib_V1.8.0）
  * 谢斌整理 
  -->本修订保留实际源码配置：HSE_VALUE=8MHz，PLL_M=8，PLL_N=336，PLL_P=2，PLL_Q=7，SYSCLK=168MHz
  -->原8MHz/M4/N336/P2注释算得336MHz，不成立；这里未按该旧注释修改时钟
  -->工程中C/C++设置时：STM32F40_41xxx,USE_STDPERIPH_DRIVER
  -->
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "usermain.h"
#include "key_filter.h"

/** @addtogroup Template_Project
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
static __IO uint32_t uwTimingDelay;
RCC_ClocksTypeDef RCC_Clocks;

static KeyFilter key_filter = KEY_FILTER_INITIALIZER;
uint8_t Index=0;
static volatile uint32_t key_millis = 0U;

/* Private function prototypes -----------------------------------------------*/
static void Delay(__IO uint32_t nTime);

void LEDKEY_Init(void);

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
int main(void)
{
 
  /* SysTick end of count event each 1 ms; original 8 MHz HSE retained. */
  RCC_GetClocksFreq(&RCC_Clocks);
  SysTick_Config(RCC_Clocks.HCLK_Frequency / 1000);
  
  /* Add your application code here */
  /* Insert nominal 5 ms delay */
  Delay(5);
  LEDKEY_Init();

  
     
  /* Infinite loop */
  while (1)
  {
		/* PF6 active-low teacher key; re-sample every loop, count stable falling edges. */
        if (KeyFilter_Update(&key_filter, GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_6), key_millis)) {
            Index = (uint8_t)((Index + 1U) % 4U);
        }
        if(Index%4 == 1) {
			GPIO_WriteBit (GPIOE, GPIO_Pin_3, Bit_RESET);
			GPIO_WriteBit (GPIOE, GPIO_Pin_4, Bit_RESET);
			Delay (1); /* Existing 1 ms SysTick timebase. */
		}else if(Index%4 == 2) { 
			GPIO_WriteBit (GPIOE, GPIO_Pin_3, Bit_RESET);
			GPIO_WriteBit (GPIOE, GPIO_Pin_4, Bit_SET);
			Delay (1); /* Existing 1 ms SysTick timebase. */
		}else if(Index%4 == 3) { 
			GPIO_WriteBit (GPIOE, GPIO_Pin_3, Bit_SET);
			GPIO_WriteBit (GPIOE, GPIO_Pin_4, Bit_RESET);
			Delay (1); /* Existing 1 ms SysTick timebase. */
		}else{
			GPIO_WriteBit (GPIOE, GPIO_Pin_3, Bit_SET);
			GPIO_WriteBit (GPIOE, GPIO_Pin_4, Bit_SET);
			Delay (1); /* Existing 1 ms SysTick timebase. */
		}
	}
}

/**
  * @brief  Inserts a delay time.
  * @param  nTime: specifies the delay time length, in milliseconds.
  * @retval None
  */
void Delay(__IO uint32_t nTime)
{ 
  uwTimingDelay = nTime;

  while(uwTimingDelay != 0);
}

/**
  * @brief  Decrements the TimingDelay variable.
  * @param  None
  * @retval None
  */
void TimingDelay_Decrement(void)
{
  ++key_millis; /* Existing SysTick_Handler calls this once per 1 ms. */
  if (uwTimingDelay != 0x00)
  { 
    uwTimingDelay--;
  }
}

//LED和KEY对应IO初始化
void LEDKEY_Init(void)
{    	 
  GPIO_InitTypeDef  GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE|RCC_AHB1Periph_GPIOF, ENABLE);	

  //PE3、PE4初始化设置
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4; 
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT; 
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;  
  GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed; 
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;  
  /* Preload off level before enabling active-low LED outputs. */
  GPIO_SetBits(GPIOE, GPIO_Pin_3 | GPIO_Pin_4);
  GPIO_Init(GPIOE, &GPIO_InitStructure);   
	
  //PF6、PF7初始化设置
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7; 	
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;    
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;  
  GPIO_Init(GPIOF, &GPIO_InitStructure);      
}			



#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
