
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#define __IO volatile
#define GPIOE 0
#define GPIOF 1
#define GPIOB 2
#define GPIOA 3
#define GPIOC 4
#define GPIOH 5
#define GPIO_PIN_RESET 0
#define GPIO_PIN_SET 1
#define Bit_RESET 0
#define Bit_SET 1
#define GPIO_MODE_OUTPUT_PP 1
#define GPIO_MODE_INPUT 2
#define GPIO_Mode_OUT 1
#define GPIO_Mode_IN 2
#define GPIO_OType_PP 1
#define GPIO_PULLUP 1
#define GPIO_PuPd_UP 1
#define GPIO_NOPULL 0
#define GPIO_SPEED_FREQ_VERY_HIGH 3
#define GPIO_SPEED_FREQ_LOW 0
#define GPIO_High_Speed 3
#define ENABLE 1
#define RCC_AHB1Periph_GPIOE 1
#define RCC_AHB1Periph_GPIOF 2
#define __HAL_RCC_GPIOE_CLK_ENABLE() (clock_enabled[GPIOE]=1U)
#define __HAL_RCC_GPIOF_CLK_ENABLE() (clock_enabled[GPIOF]=1U)
#define __HAL_RCC_GPIOB_CLK_ENABLE() (clock_enabled[GPIOB]=1U)
#define __HAL_RCC_GPIOH_CLK_ENABLE() (clock_enabled[GPIOH]=1U)
#define __HAL_RCC_GPIOA_CLK_ENABLE() (clock_enabled[GPIOA]=1U)
#define __HAL_RCC_GPIOC_CLK_ENABLE() (clock_enabled[GPIOC]=1U)
typedef struct { unsigned Pin,Mode,Pull,Speed; unsigned GPIO_Pin,GPIO_Mode,GPIO_OType,GPIO_PuPd,GPIO_Speed; } GPIO_InitTypeDef;
static uint16_t odr[6], output_mask[6], input_mask[6], pullup_mask[6];
static unsigned clock_enabled[6];
static unsigned raw=1, simulated_low_enable=0;
static uint32_t tick;
static void write_pin(unsigned port,unsigned pin,unsigned state) {
    assert(port < 6U); assert(pin <= 65535U); assert(clock_enabled[port]);
    if(state) odr[port]|=(uint16_t)pin; else odr[port]&=(uint16_t)~pin;
}
#define HAL_GPIO_WritePin write_pin
#define GPIO_WriteBit write_pin
#define HAL_GPIO_TogglePin(p,m) (odr[(p)]^=(m))
#define GPIO_SetBits(p,m) write_pin(p,m,1)
static void gpio_init(unsigned p, GPIO_InitTypeDef *g) {
    assert(p < 6U && clock_enabled[p]);
    unsigned pin=g->Pin;
    unsigned mode=g->Mode;
    if(mode==1U && (odr[p] & pin)!=pin) simulated_low_enable++;
    if(mode==GPIO_MODE_OUTPUT_PP) { output_mask[p]|=pin; input_mask[p]&=~pin; }
    else if(mode==GPIO_MODE_INPUT) { input_mask[p]|=pin; output_mask[p]&=~pin; }
    if(g->Pull==GPIO_PULLUP) pullup_mask[p]|=pin; else pullup_mask[p]&=~pin;
}
#define HAL_GPIO_Init gpio_init
static void spl_gpio_init(unsigned p, GPIO_InitTypeDef *g) {
    unsigned pin=g->GPIO_Pin;
    assert(p < 6U && clock_enabled[p]);
    if(g->GPIO_Mode==1U && (odr[p]&pin)!=pin) simulated_low_enable++;
    if(g->GPIO_Mode==GPIO_Mode_OUT) { assert(g->GPIO_OType==GPIO_OType_PP); output_mask[p]|=pin; input_mask[p]&=~pin; }
    else if(g->GPIO_Mode==GPIO_Mode_IN) { input_mask[p]|=pin; output_mask[p]&=~pin; }
    if(g->GPIO_PuPd==GPIO_PuPd_UP) pullup_mask[p]|=pin; else pullup_mask[p]&=~pin;
}
#define GPIO_Init spl_gpio_init
static void spl_clock_enable(unsigned mask,unsigned enabled) {
    if(mask&RCC_AHB1Periph_GPIOE) clock_enabled[GPIOE]=enabled;
    if(mask&RCC_AHB1Periph_GPIOF) clock_enabled[GPIOF]=enabled;
}
#define RCC_AHB1PeriphClockCmd spl_clock_enable
static unsigned read_key(unsigned p,unsigned m) { assert(p==GPIOF && m==64U); return raw; }
#define HAL_GPIO_ReadPin read_key
#define GPIO_ReadInputDataBit read_key
#define HAL_GetTick() (tick)
/* Delays are deliberately stubs: no tick/ISR/electrical timing is simulated. */
static unsigned requested_delay;
#define HAL_Delay(ms) (requested_delay=(ms))
#define Delay(ms) (requested_delay=(ms))
#define GPIO_PIN_0 (1U << 0)
#define GPIO_Pin_0 (1U << 0)
#define GPIO_PIN_1 (1U << 1)
#define GPIO_Pin_1 (1U << 1)
#define GPIO_PIN_2 (1U << 2)
#define GPIO_Pin_2 (1U << 2)
#define GPIO_PIN_3 (1U << 3)
#define GPIO_Pin_3 (1U << 3)
#define GPIO_PIN_4 (1U << 4)
#define GPIO_Pin_4 (1U << 4)
#define GPIO_PIN_5 (1U << 5)
#define GPIO_Pin_5 (1U << 5)
#define GPIO_PIN_6 (1U << 6)
#define GPIO_Pin_6 (1U << 6)
#define GPIO_PIN_7 (1U << 7)
#define GPIO_Pin_7 (1U << 7)
#define GPIO_PIN_8 (1U << 8)
#define GPIO_Pin_8 (1U << 8)
#define GPIO_PIN_9 (1U << 9)
#define GPIO_Pin_9 (1U << 9)
#define GPIO_PIN_10 (1U << 10)
#define GPIO_Pin_10 (1U << 10)
#define GPIO_PIN_11 (1U << 11)
#define GPIO_Pin_11 (1U << 11)
#define GPIO_PIN_12 (1U << 12)
#define GPIO_Pin_12 (1U << 12)
#define GPIO_PIN_13 (1U << 13)
#define GPIO_Pin_13 (1U << 13)
#define GPIO_PIN_14 (1U << 14)
#define GPIO_Pin_14 (1U << 14)
#define GPIO_PIN_15 (1U << 15)
#define GPIO_Pin_15 (1U << 15)
#define LED2_Pin GPIO_PIN_3
#define LED2_GPIO_Port GPIOE
#define LED3_Pin GPIO_PIN_4
#define LED3_GPIO_Port GPIOE
#define YLED0_Pin GPIO_PIN_0
#define YLED0_GPIO_Port GPIOB
#define YLED1_Pin GPIO_PIN_1
#define YLED1_GPIO_Port GPIOB
#define YLED2_Pin GPIO_PIN_2
#define YLED2_GPIO_Port GPIOB
#define YLED3_Pin GPIO_PIN_3
#define YLED3_GPIO_Port GPIOB
#define YLED4_Pin GPIO_PIN_4
#define YLED4_GPIO_Port GPIOB
#define YLED5_Pin GPIO_PIN_5
#define YLED5_GPIO_Port GPIOB
#define YLED6_Pin GPIO_PIN_6
#define YLED6_GPIO_Port GPIOB
#define YLED7_Pin GPIO_PIN_7
#define YLED7_GPIO_Port GPIOB

/* Revision: teacher PE3/PE4/PB0..7 board; original 8 MHz HSE retained. */
uint16_t GPIO_PIN[]={ YLED0_Pin,YLED1_Pin,YLED2_Pin,YLED3_Pin,YLED4_Pin,YLED5_Pin,YLED6_Pin,YLED7_Pin};
uint16_t Number=0;
static uint8_t HeartbeatSteps = 0U;

static void init_gpio(void) {


  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  /* deliberately omitted in temporary negative test */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, LED2_Pin|LED3_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, YLED0_Pin|YLED1_Pin|YLED2_Pin|YLED3_Pin
                          |YLED4_Pin|YLED5_Pin|YLED6_Pin|YLED7_Pin, GPIO_PIN_SET); /* Active-low LEDs: start off. */

  /*Configure GPIO pins : PEPin PEPin */
  GPIO_InitStruct.Pin = LED2_Pin|LED3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : PBPin PBPin PBPin PBPin
                           PBPin PBPin PBPin PBPin */
  GPIO_InitStruct.Pin = YLED0_Pin|YLED1_Pin|YLED2_Pin|YLED3_Pin
                          |YLED4_Pin|YLED5_Pin|YLED6_Pin|YLED7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);


}
static void app_step(void) {

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		
		HAL_Delay (100); /* Chosen running-light step: 100 ms. */
		
		if (++HeartbeatSteps == 5U) { /* 5 x 100 ms toggle: nominal 1 Hz cycle. */
            HeartbeatSteps = 0U;
            HAL_GPIO_TogglePin(GPIOE, LED2_Pin);
        }
		
		HAL_GPIO_WritePin(GPIOB, YLED0_Pin|YLED1_Pin|YLED2_Pin|YLED3_Pin
                          |YLED4_Pin|YLED5_Pin|YLED6_Pin|YLED7_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN[Number], GPIO_PIN_RESET);
		
		Number++;
		if(Number==8)
			Number=0;
		
  
}

int main(void) {
    unsigned i;
    init_gpio();
    printf("startup_pb_mask=%u\n",odr[GPIOB]&255U);
    printf("low_output_enable_calls=%u\n",simulated_low_enable);
    assert((odr[GPIOB]&255U)==255U);
    assert(simulated_low_enable==0U);
    assert((odr[GPIOE]&24U)==24U);
    assert((output_mask[GPIOE]&24U)==24U);
    assert((output_mask[GPIOB]&255U)==255U);
    for(i=0;i<70000U;i++) {
        app_step();
        assert(requested_delay==100U);
        assert((odr[GPIOB]&255U)==(255U^(1U<<(i%8U))));
        assert(((odr[GPIOE]>>3)&1U)==(1U^(((i+1U)/5U)&1U)));
        assert((odr[GPIOE]&16U)==16U);
        assert(Number==(i+1U)%8U);
    }
    puts("PASS: 70000 running-light steps, eight outputs, heartbeat every five steps, PE4 unchanged");
    return 0;
}
