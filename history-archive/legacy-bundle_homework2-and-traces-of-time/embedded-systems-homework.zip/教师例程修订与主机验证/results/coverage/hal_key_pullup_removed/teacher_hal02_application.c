
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#define __IO volatile
#define GPIOE 0
#define GPIOF 1
#define GPIOB 2
#define GPIOA 3
#define GPIOC 4
#define GPIOH 5
#define GPIO_PIN_RESET 0
#define GPIO_PIN_SET 1
#define Bit_RESET 0
#define Bit_SET 1
#define GPIO_MODE_OUTPUT_PP 1
#define GPIO_MODE_INPUT 2
#define GPIO_Mode_OUT 1
#define GPIO_Mode_IN 2
#define GPIO_OType_PP 1
#define GPIO_PULLUP 1
#define GPIO_PuPd_UP 1
#define GPIO_NOPULL 0
#define GPIO_SPEED_FREQ_VERY_HIGH 3
#define GPIO_SPEED_FREQ_LOW 0
#define GPIO_High_Speed 3
#define ENABLE 1
#define RCC_AHB1Periph_GPIOE 1
#define RCC_AHB1Periph_GPIOF 2
#define __HAL_RCC_GPIOE_CLK_ENABLE() (clock_enabled[GPIOE]=1U)
#define __HAL_RCC_GPIOF_CLK_ENABLE() (clock_enabled[GPIOF]=1U)
#define __HAL_RCC_GPIOB_CLK_ENABLE() (clock_enabled[GPIOB]=1U)
#define __HAL_RCC_GPIOH_CLK_ENABLE() (clock_enabled[GPIOH]=1U)
#define __HAL_RCC_GPIOA_CLK_ENABLE() (clock_enabled[GPIOA]=1U)
#define __HAL_RCC_GPIOC_CLK_ENABLE() (clock_enabled[GPIOC]=1U)
typedef struct { unsigned Pin,Mode,Pull,Speed; unsigned GPIO_Pin,GPIO_Mode,GPIO_OType,GPIO_PuPd,GPIO_Speed; } GPIO_InitTypeDef;
static uint16_t odr[6], output_mask[6], input_mask[6], pullup_mask[6];
static unsigned clock_enabled[6];
static unsigned raw=1, simulated_low_enable=0;
static uint32_t tick;
static void write_pin(unsigned port,unsigned pin,unsigned state) {
    assert(port < 6U); assert(pin <= 65535U); assert(clock_enabled[port]);
    if(state) odr[port]|=(uint16_t)pin; else odr[port]&=(uint16_t)~pin;
}
#define HAL_GPIO_WritePin write_pin
#define GPIO_WriteBit write_pin
#define HAL_GPIO_TogglePin(p,m) (odr[(p)]^=(m))
#define GPIO_SetBits(p,m) write_pin(p,m,1)
static void gpio_init(unsigned p, GPIO_InitTypeDef *g) {
    assert(p < 6U && clock_enabled[p]);
    unsigned pin=g->Pin;
    unsigned mode=g->Mode;
    if(mode==1U && (odr[p] & pin)!=pin) simulated_low_enable++;
    if(mode==GPIO_MODE_OUTPUT_PP) { output_mask[p]|=pin; input_mask[p]&=~pin; }
    else if(mode==GPIO_MODE_INPUT) { input_mask[p]|=pin; output_mask[p]&=~pin; }
    if(g->Pull==GPIO_PULLUP) pullup_mask[p]|=pin; else pullup_mask[p]&=~pin;
}
#define HAL_GPIO_Init gpio_init
static void spl_gpio_init(unsigned p, GPIO_InitTypeDef *g) {
    unsigned pin=g->GPIO_Pin;
    assert(p < 6U && clock_enabled[p]);
    if(g->GPIO_Mode==1U && (odr[p]&pin)!=pin) simulated_low_enable++;
    if(g->GPIO_Mode==GPIO_Mode_OUT) { assert(g->GPIO_OType==GPIO_OType_PP); output_mask[p]|=pin; input_mask[p]&=~pin; }
    else if(g->GPIO_Mode==GPIO_Mode_IN) { input_mask[p]|=pin; output_mask[p]&=~pin; }
    if(g->GPIO_PuPd==GPIO_PuPd_UP) pullup_mask[p]|=pin; else pullup_mask[p]&=~pin;
}
#define GPIO_Init spl_gpio_init
static void spl_clock_enable(unsigned mask,unsigned enabled) {
    if(mask&RCC_AHB1Periph_GPIOE) clock_enabled[GPIOE]=enabled;
    if(mask&RCC_AHB1Periph_GPIOF) clock_enabled[GPIOF]=enabled;
}
#define RCC_AHB1PeriphClockCmd spl_clock_enable
static unsigned read_key(unsigned p,unsigned m) { assert(p==GPIOF && m==64U); return raw; }
#define HAL_GPIO_ReadPin read_key
#define GPIO_ReadInputDataBit read_key
#define HAL_GetTick() (tick)
/* Delays are deliberately stubs: no tick/ISR/electrical timing is simulated. */
static unsigned requested_delay;
#define HAL_Delay(ms) (requested_delay=(ms))
#define Delay(ms) (requested_delay=(ms))
#define GPIO_PIN_0 (1U << 0)
#define GPIO_Pin_0 (1U << 0)
#define GPIO_PIN_1 (1U << 1)
#define GPIO_Pin_1 (1U << 1)
#define GPIO_PIN_2 (1U << 2)
#define GPIO_Pin_2 (1U << 2)
#define GPIO_PIN_3 (1U << 3)
#define GPIO_Pin_3 (1U << 3)
#define GPIO_PIN_4 (1U << 4)
#define GPIO_Pin_4 (1U << 4)
#define GPIO_PIN_5 (1U << 5)
#define GPIO_Pin_5 (1U << 5)
#define GPIO_PIN_6 (1U << 6)
#define GPIO_Pin_6 (1U << 6)
#define GPIO_PIN_7 (1U << 7)
#define GPIO_Pin_7 (1U << 7)
#define GPIO_PIN_8 (1U << 8)
#define GPIO_Pin_8 (1U << 8)
#define GPIO_PIN_9 (1U << 9)
#define GPIO_Pin_9 (1U << 9)
#define GPIO_PIN_10 (1U << 10)
#define GPIO_Pin_10 (1U << 10)
#define GPIO_PIN_11 (1U << 11)
#define GPIO_Pin_11 (1U << 11)
#define GPIO_PIN_12 (1U << 12)
#define GPIO_Pin_12 (1U << 12)
#define GPIO_PIN_13 (1U << 13)
#define GPIO_Pin_13 (1U << 13)
#define GPIO_PIN_14 (1U << 14)
#define GPIO_Pin_14 (1U << 14)
#define GPIO_PIN_15 (1U << 15)
#define GPIO_Pin_15 (1U << 15)
#define LED2_Pin GPIO_PIN_3
#define LED2_GPIO_Port GPIOE
#define LED3_Pin GPIO_PIN_4
#define LED3_GPIO_Port GPIOE
#define KEY3_Pin GPIO_PIN_6
#define KEY3_GPIO_Port GPIOF
#define KEY4_Pin GPIO_PIN_7
#define KEY4_GPIO_Port GPIOF
#ifndef KEY_FILTER_H
#define KEY_FILTER_H
#include <stdint.h>
/* Active-low key, sampled regularly. Stable press emits exactly one event.
 * Stable release rearms it. Startup assumes released; holding at startup
 * produces one event after 20 ms. Unsigned elapsed arithmetic tolerates wrap. */
typedef struct {
    uint32_t changed_at;
    uint8_t candidate;
    uint8_t stable;
} KeyFilter;
#define KEY_FILTER_INITIALIZER {0U, 1U, 1U}
static uint8_t KeyFilter_Update(KeyFilter *key, uint8_t raw, uint32_t now)
{
    raw = (raw != 0U) ? 1U : 0U;
    if (raw != key->candidate) {
        key->candidate = raw;
        key->changed_at = now;
    }
    if (key->stable != key->candidate &&
        (uint32_t)(now - key->changed_at) >= 20U) {
        key->stable = key->candidate;
        return (key->stable == 0U) ? 1U : 0U;
    }
    return 0U;
}
#endif

static KeyFilter key_filter = KEY_FILTER_INITIALIZER;
uint8_t Index=0;


static void init_gpio(void) {


  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, LED2_Pin|LED3_Pin, GPIO_PIN_SET);

  /*Configure GPIO pins : PEPin PEPin */
  GPIO_InitStruct.Pin = LED2_Pin|LED3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : PFPin PFPin */
  GPIO_InitStruct.Pin = KEY3_Pin|KEY4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);


}
static void app_step(void) {

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		/* PF6 active-low teacher key; re-sample every loop, count stable falling edges. */
        if (KeyFilter_Update(&key_filter, (uint8_t)HAL_GPIO_ReadPin(GPIOF, KEY3_Pin), HAL_GetTick())) {
            Index = (uint8_t)((Index + 1U) % 4U);
        }
        if(Index%4 == 1) {
			HAL_GPIO_WritePin (GPIOE, LED2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin (GPIOE, LED3_Pin, GPIO_PIN_RESET);
			HAL_Delay (1); /* Poll regularly; debounce owns the 20 ms window. */
		}else if(Index%4 == 2) { 
			HAL_GPIO_WritePin (GPIOE, LED2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin (GPIOE, LED3_Pin, GPIO_PIN_SET);
			HAL_Delay (1); /* Poll regularly; debounce owns the 20 ms window. */
		}else if(Index%4 == 3) { 
			HAL_GPIO_WritePin (GPIOE, LED2_Pin, GPIO_PIN_SET);
			HAL_GPIO_WritePin (GPIOE, LED3_Pin, GPIO_PIN_RESET);
			HAL_Delay (1); /* Poll regularly; debounce owns the 20 ms window. */
		}else{
			HAL_GPIO_WritePin (GPIOE, LED2_Pin, GPIO_PIN_SET);
			HAL_GPIO_WritePin (GPIOE, LED3_Pin, GPIO_PIN_SET);
			HAL_Delay (1); /* Poll regularly; debounce owns the 20 ms window. */
		}
	
}

static unsigned elapsed, presses;
static void sample(unsigned level, unsigned expected_index) {
    raw=level;
    tick=0xfffffff0U+elapsed;
    app_step();
    assert(requested_delay==1U);
    assert(Index==expected_index);
    { static const unsigned levels[]={24U,0U,16U,8U};
      assert((odr[GPIOE]&24U)==levels[expected_index]); }
    ++elapsed;
}
static void samples(unsigned level,unsigned count,unsigned expected_index) {
    unsigned i;for(i=0;i<count;i++) sample(level,expected_index);
}
static void press(void) {
    samples(0U,20U,presses%4U); /* not accepted before the 20ms boundary */
    ++presses; sample(0U,presses%4U);
    samples(0U,1000U,presses%4U); /* long hold must not repeat */
}
int main(void) {
    unsigned n;
    init_gpio();
    printf("low_output_enable_calls=%u\n",simulated_low_enable);
    assert(simulated_low_enable==0U);
    assert((odr[GPIOE]&24U)==24U);
    assert((output_mask[GPIOE]&24U)==24U);
    assert((input_mask[GPIOF]&64U)==64U);
    assert((pullup_mask[GPIOF]&64U)==64U);
    samples(1U,10U,0U);
    samples(0U,19U,0U);samples(1U,30U,0U); /* sub-window glitch */
    samples(0U,5U,0U);samples(1U,3U,0U);samples(0U,5U,0U);samples(1U,2U,0U);
    press();
    samples(1U,19U,1U);samples(0U,40U,1U); /* short release cannot rearm */
    samples(1U,21U,1U);
    for(n=0;n<299U;n++) {press();samples(1U,21U,presses%4U);}
    assert(presses==300U && Index==0U);
    /* Startup held: reset only state, with elapsed wrapping through uint32. */
    key_filter=(KeyFilter)KEY_FILTER_INITIALIZER; Index=0U; presses=0U; elapsed=0U;
    press();
    /* Irregular sampling: elapsed time, not sample count, sets the boundary. */
    key_filter=(KeyFilter)KEY_FILTER_INITIALIZER; Index=0U;
    elapsed=0U; sample(0U,0U);
    elapsed=2U; sample(0U,0U);
    elapsed=7U; sample(0U,0U);
    elapsed=19U; sample(0U,0U);
    elapsed=20U; sample(0U,1U);
    elapsed=2000U; sample(0U,1U);
    elapsed=2003U; sample(1U,1U);
    elapsed=2022U; sample(1U,1U);
    elapsed=2023U; sample(1U,1U);
    elapsed=2025U; sample(0U,1U);
    elapsed=2044U; sample(0U,1U);
    elapsed=2045U; sample(0U,2U);
    puts("PASS: exact LED order for 300 presses, bounce, hold, rearm, startup held, uint32 rollover, irregular sampling");
    return 0;
}
