"""Source-derived configuration checks, not target compilation or device emulation.
Uses the actual uvprojx target macros/include order and host GCC preprocessor.
Only simple integer constants/expressions used by these projects are accepted.
"""
from pathlib import Path
import ast,hashlib,re,subprocess,xml.etree.ElementTree as ET

def integer(expr,macros,seen=()):
    expr=re.sub(r'\((?:u?int(?:8|16|32|64)_t)\)','',expr)
    expr=re.sub(r'\b(0[xX][0-9a-fA-F]+|\d+)[uUlL]+\b',r'\1',expr)
    def node(n):
        if isinstance(n,ast.Constant) and type(n.value)==int:return n.value
        if isinstance(n,ast.Name) and n.id in macros and n.id not in seen:return integer(macros[n.id],macros,seen+(n.id,))
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):return node(n.operand)*(1 if isinstance(n.op,ast.UAdd) else -1)
        if isinstance(n,ast.BinOp):
            a,b=node(n.left),node(n.right)
            operations={ast.Add:lambda:a+b,ast.Sub:lambda:a-b,ast.Mult:lambda:a*b,ast.LShift:lambda:a<<b,ast.RShift:lambda:a>>b,ast.BitOr:lambda:a|b,ast.BitAnd:lambda:a&b}
            if type(n.op) in operations:return operations[type(n.op)]()
        raise ValueError('Unsupported integer expression: '+expr)
    return node(ast.parse(expr.strip(),mode='eval').body)

def inspect_project(project_dir):
    b=Path(project_dir).resolve(); projects=list(b.rglob('*.uvprojx'))
    if len(projects)!=1:raise ValueError('Expected one uvprojx in '+str(b))
    p=projects[0]; root=ET.parse(p).getroot(); targets=root.findall('./Targets/Target')
    if len(targets)!=1:raise ValueError('Multiple/no targets must be reviewed explicitly: '+str(p))
    target=targets[0]; cc=target.find('./TargetOption/TargetArmAds/Cads/VariousControls')
    defines=[x.strip() for x in (cc.findtext('Define') or '').split(',') if x.strip()]
    includes=[(p.parent/x.replace('\\','/')).resolve() for x in (cc.findtext('IncludePath') or '').split(';') if x]
    files=[(p.parent/x.text.replace('\\','/')).resolve() for x in target.findall('.//Groups/Group/Files/File/FilePath')]
    systems=[x for x in files if x.name=='system_stm32f4xx.c']
    if len(systems)!=1:raise ValueError('Expected exactly one selected system source')
    source=systems[0]
    cmd=['gcc','-E','-dM']+['-D'+x for x in defines]+['-I'+str(x) for x in includes]+[str(source)]
    r=subprocess.run(cmd,text=True,capture_output=True,timeout=30)
    if r.returncode:raise RuntimeError('Preprocessing failed for '+str(p)+'\n'+r.stderr)
    macros=dict(re.findall(r'^#define (\w+) (.+)$',r.stdout,re.M)); hse=integer(macros['HSE_VALUE'],macros)
    if 'USE_HAL_DRIVER' in defines:
        mains=[x for x in files if x.name=='main.c']
        if len(mains)!=1:raise ValueError('Expected exactly one selected HAL main source')
        main=mains[0]; text=main.read_text(encoding='utf-8-sig')
        text=re.sub(r'/\*.*?\*/|//[^\n]*','',text,flags=re.S)
        if not re.search(r'PLL\.PLLSource\s*=\s*RCC_PLLSOURCE_HSE\s*;',text):raise ValueError('This checker only covers the declared HSE clock configuration')
        values={}
        for k in 'MNPQ':
            found=re.findall(r'PLL\.PLL'+k+r'\s*=\s*([^;]+);',text)
            if len(found)!=1:raise ValueError('Ambiguous HAL PLL'+k)
            values[k]=integer(found[0],macros)
    else:
        main=source; values={k:integer(macros['PLL_'+k],macros) for k in 'MNPQ'}
        text=source.read_text(encoding='utf-8-sig')
        if 'RCC_PLLCFGR_PLLSRC_HSE' not in text:raise ValueError('Expected HSE branch in selected STD system source')
    used=[p,source,main]
    # Keep header identities too; preprocessing above determines which macro wins.
    used+=list(b.glob('Core/Inc/stm32f4xx_hal_conf.h'))+list(b.glob('UserMain/stm32f4xx.h'))
    result={'profile':b.name,'HSE_VALUE_Hz':hse,**values,'device':target.findtext('./TargetOption/TargetCommonOption/Device'),'project_file':str(p.relative_to(b)),'defines':defines,'include_paths':[str(x.relative_to(b)) for x in includes],'source_sha256':{str(x.relative_to(b)):hashlib.sha256(x.read_bytes()).hexdigest() for x in dict.fromkeys(used)},'preprocessor':'host GCC -E -dM with selected project defines and includes; no ARM code generation'}
    iocs=list(b.glob('*.ioc'))
    if iocs:
        if len(iocs)!=1:raise ValueError('Expected one IOC')
        pairs=dict(x.split('=',1) for x in iocs[0].read_text().splitlines() if '=' in x)
        checks={'RCC.HSE_VALUE':hse,'RCC.PLLM':values['M'],'RCC.PLLN':values['N'],'RCC.PLLQ':values['Q']}
        for k,v in checks.items():
            if int(pairs[k])!=v:raise ValueError(f'IOC/source mismatch: {b.name} {k}: {pairs[k]} vs {v}')
        result['ioc_checked']={k:pairs[k] for k in checks}
    return result

def clock_case(name,config,hse_hz=None,q=None,kind='source-derived'):
    c={'case':name,'kind':kind,'profile':config['profile'],'hse_MHz':(config['HSE_VALUE_Hz'] if hse_hz is None else hse_hz)/1e6,**{k:config[k] for k in 'MNPQ'}}
    if q is not None:c['Q']=q
    c['PLL_input_MHz']=c['hse_MHz']/c['M'];c['VCO_MHz']=c['PLL_input_MHz']*c['N'];c['SYSCLK_ideal_MHz']=c['VCO_MHz']/c['P'];c['PLLQ_ideal_MHz']=c['VCO_MHz']/c['Q']
    # ST DS8626 Rev12 table36, p106; only these clock-range checks, not full electrical signoff.
    c['within_pll_input_range']=0.95<=c['PLL_input_MHz']<=2.10
    c['within_vco_range']=100<=c['VCO_MHz']<=432
    c['within_sysclk_range']=24<=c['SYSCLK_ideal_MHz']<=168
    c['within_pll48_upper_bound']=c['PLLQ_ideal_MHz']<=75
    c['within_checked_clock_limits']=all(c[x] for x in ['within_pll_input_range','within_vco_range','within_sysclk_range','within_pll48_upper_bound'])
    return c

def read_all(projects):
    return {name:inspect_project(Path(projects)/name) for name in ['teacher_hal','teacher_hal02','teacher_spl02']}
