#!/usr/bin/env python3
"""HOST-ONLY execution of exact application loop/GPIO excerpts, with explicit mocks.
Does not build ARM code, run a device simulator, or model electrical behavior.
Python 3 stdlib + host GCC. Generated C and logs retained for inspection.
"""
from pathlib import Path
import argparse, hashlib, json, re, subprocess
B=Path(__file__).resolve().parents[1]
P=argparse.ArgumentParser(description=__doc__)
P.add_argument('--projects',type=Path,default=B/'verified_projects')
P.add_argument('--out',type=Path,default=B/'results/application')
P.add_argument('--require-safe-start',action='store_true',help='Require all active-low LED outputs to be preloaded high before output enable')
a=P.parse_args(); a.out.mkdir(parents=True,exist_ok=True)
records=[]; sources={}
def read(p):
    sources[str(p.relative_to(a.projects))]=hashlib.sha256(p.read_bytes()).hexdigest()
    return p.read_text(encoding='utf-8-sig')
def block(s,start):
    # Mask comments and strings without moving brace offsets.
    mask=re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:' '*len(m[0]),s,flags=re.S)
    i=mask.index('{',start); depth=1; j=i+1
    while depth:
        depth+=(mask[j]=='{')-(mask[j]=='}'); j+=1
    return s[i+1:j-1]
def func(s,name):
    m=re.search(r'\b'+name+r'\s*\([^;{}]*\)\s*\{',s)
    if not m: raise RuntimeError('Function not found: '+name)
    return block(s,m.start())
common=r'''
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#define __IO volatile
#define GPIOE 0
#define GPIOF 1
#define GPIOB 2
#define GPIOA 3
#define GPIOC 4
#define GPIOH 5
#define GPIO_PIN_RESET 0
#define GPIO_PIN_SET 1
#define Bit_RESET 0
#define Bit_SET 1
#define GPIO_MODE_OUTPUT_PP 1
#define GPIO_MODE_INPUT 2
#define GPIO_Mode_OUT 1
#define GPIO_Mode_IN 2
#define GPIO_OType_PP 1
#define GPIO_PULLUP 1
#define GPIO_PuPd_UP 1
#define GPIO_NOPULL 0
#define GPIO_SPEED_FREQ_VERY_HIGH 3
#define GPIO_SPEED_FREQ_LOW 0
#define GPIO_High_Speed 3
#define ENABLE 1
#define RCC_AHB1Periph_GPIOE 1
#define RCC_AHB1Periph_GPIOF 2
#define __HAL_RCC_GPIOE_CLK_ENABLE() (clock_enabled[GPIOE]=1U)
#define __HAL_RCC_GPIOF_CLK_ENABLE() (clock_enabled[GPIOF]=1U)
#define __HAL_RCC_GPIOB_CLK_ENABLE() (clock_enabled[GPIOB]=1U)
#define __HAL_RCC_GPIOH_CLK_ENABLE() (clock_enabled[GPIOH]=1U)
#define __HAL_RCC_GPIOA_CLK_ENABLE() (clock_enabled[GPIOA]=1U)
#define __HAL_RCC_GPIOC_CLK_ENABLE() (clock_enabled[GPIOC]=1U)
typedef struct { unsigned Pin,Mode,Pull,Speed; unsigned GPIO_Pin,GPIO_Mode,GPIO_OType,GPIO_PuPd,GPIO_Speed; } GPIO_InitTypeDef;
static uint16_t odr[6], output_mask[6], input_mask[6], pullup_mask[6];
static unsigned clock_enabled[6];
static unsigned raw=1, simulated_low_enable=0;
static uint32_t tick;
static void write_pin(unsigned port,unsigned pin,unsigned state) {
    assert(port < 6U); assert(pin <= 65535U); assert(clock_enabled[port]);
    if(state) odr[port]|=(uint16_t)pin; else odr[port]&=(uint16_t)~pin;
}
#define HAL_GPIO_WritePin write_pin
#define GPIO_WriteBit write_pin
#define HAL_GPIO_TogglePin(p,m) (odr[(p)]^=(m))
#define GPIO_SetBits(p,m) write_pin(p,m,1)
static void gpio_init(unsigned p, GPIO_InitTypeDef *g) {
    assert(p < 6U && clock_enabled[p]);
    unsigned pin=g->Pin;
    unsigned mode=g->Mode;
    if(mode==1U && (odr[p] & pin)!=pin) simulated_low_enable++;
    if(mode==GPIO_MODE_OUTPUT_PP) { output_mask[p]|=pin; input_mask[p]&=~pin; }
    else if(mode==GPIO_MODE_INPUT) { input_mask[p]|=pin; output_mask[p]&=~pin; }
    if(g->Pull==GPIO_PULLUP) pullup_mask[p]|=pin; else pullup_mask[p]&=~pin;
}
#define HAL_GPIO_Init gpio_init
static void spl_gpio_init(unsigned p, GPIO_InitTypeDef *g) {
    unsigned pin=g->GPIO_Pin;
    assert(p < 6U && clock_enabled[p]);
    if(g->GPIO_Mode==1U && (odr[p]&pin)!=pin) simulated_low_enable++;
    if(g->GPIO_Mode==GPIO_Mode_OUT) { assert(g->GPIO_OType==GPIO_OType_PP); output_mask[p]|=pin; input_mask[p]&=~pin; }
    else if(g->GPIO_Mode==GPIO_Mode_IN) { input_mask[p]|=pin; output_mask[p]&=~pin; }
    if(g->GPIO_PuPd==GPIO_PuPd_UP) pullup_mask[p]|=pin; else pullup_mask[p]&=~pin;
}
#define GPIO_Init spl_gpio_init
static void spl_clock_enable(unsigned mask,unsigned enabled) {
    if(mask&RCC_AHB1Periph_GPIOE) clock_enabled[GPIOE]=enabled;
    if(mask&RCC_AHB1Periph_GPIOF) clock_enabled[GPIOF]=enabled;
}
#define RCC_AHB1PeriphClockCmd spl_clock_enable
static unsigned read_key(unsigned p,unsigned m) { assert(p==GPIOF && m==64U); return raw; }
#define HAL_GPIO_ReadPin read_key
#define GPIO_ReadInputDataBit read_key
#define HAL_GetTick() (tick)
/* Delays are deliberately stubs: no tick/ISR/electrical timing is simulated. */
static unsigned requested_delay;
#define HAL_Delay(ms) (requested_delay=(ms))
#define Delay(ms) (requested_delay=(ms))
'''
for i in range(16): common+=f'#define GPIO_PIN_{i} (1U << {i})\n#define GPIO_Pin_{i} (1U << {i})\n'
runner=r'''
int main(void) {
    unsigned i;
    init_gpio();
    printf("startup_pb_mask=%u\n",odr[GPIOB]&255U);
    printf("low_output_enable_calls=%u\n",simulated_low_enable);
    REQUIRE_DARK
    REQUIRE_SAFE
    assert((odr[GPIOE]&24U)==24U);
    assert((output_mask[GPIOE]&24U)==24U);
    assert((output_mask[GPIOB]&255U)==255U);
    for(i=0;i<70000U;i++) {
        app_step();
        assert(requested_delay==100U);
        assert((odr[GPIOB]&255U)==(255U^(1U<<(i%8U))));
        assert(((odr[GPIOE]>>3)&1U)==(1U^(((i+1U)/5U)&1U)));
        assert((odr[GPIOE]&16U)==16U);
        assert(Number==(i+1U)%8U);
    }
    puts("PASS: 70000 running-light steps, eight outputs, heartbeat every five steps, PE4 unchanged");
    return 0;
}
'''
keytest=r'''
static unsigned elapsed, presses;
static void sample(unsigned level, unsigned expected_index) {
    raw=level;
    SET_TICK
    app_step();
    assert(requested_delay==1U);
    assert(Index==expected_index);
    { static const unsigned levels[]={24U,0U,16U,8U};
      assert((odr[GPIOE]&24U)==levels[expected_index]); }
    ++elapsed;
}
static void samples(unsigned level,unsigned count,unsigned expected_index) {
    unsigned i;for(i=0;i<count;i++) sample(level,expected_index);
}
static void press(void) {
    samples(0U,20U,presses%4U); /* not accepted before the 20ms boundary */
    ++presses; sample(0U,presses%4U);
    samples(0U,1000U,presses%4U); /* long hold must not repeat */
}
int main(void) {
    unsigned n;
    init_gpio();
    printf("low_output_enable_calls=%u\n",simulated_low_enable);
    REQUIRE_SAFE
    assert((odr[GPIOE]&24U)==24U);
    assert((output_mask[GPIOE]&24U)==24U);
    assert((input_mask[GPIOF]&64U)==64U);
    assert((pullup_mask[GPIOF]&64U)==64U);
    samples(1U,10U,0U);
    samples(0U,19U,0U);samples(1U,30U,0U); /* sub-window glitch */
    samples(0U,5U,0U);samples(1U,3U,0U);samples(0U,5U,0U);samples(1U,2U,0U);
    press();
    samples(1U,19U,1U);samples(0U,40U,1U); /* short release cannot rearm */
    samples(1U,21U,1U);
    for(n=0;n<299U;n++) {press();samples(1U,21U,presses%4U);}
    assert(presses==300U && Index==0U);
    /* Startup held: reset only state, with elapsed wrapping through uint32. */
    key_filter=(KeyFilter)KEY_FILTER_INITIALIZER; Index=0U; presses=0U; elapsed=0U;
    press();
    /* Irregular sampling: elapsed time, not sample count, sets the boundary. */
    key_filter=(KeyFilter)KEY_FILTER_INITIALIZER; Index=0U;
    elapsed=0U; sample(0U,0U);
    elapsed=2U; sample(0U,0U);
    elapsed=7U; sample(0U,0U);
    elapsed=19U; sample(0U,0U);
    elapsed=20U; sample(0U,1U);
    elapsed=2000U; sample(0U,1U);
    elapsed=2003U; sample(1U,1U);
    elapsed=2022U; sample(1U,1U);
    elapsed=2023U; sample(1U,1U);
    elapsed=2025U; sample(0U,1U);
    elapsed=2044U; sample(0U,1U);
    elapsed=2045U; sample(0U,2U);
    puts("PASS: exact LED order for 300 presses, bounce, hold, rearm, startup held, uint32 rollover, irregular sampling");
    return 0;
}
'''
for name in ['teacher_hal','teacher_hal02','teacher_spl02']:
    b=a.projects/name; hal=name!='teacher_spl02'
    main=read(b/('Core/Src/main.c' if hal else 'UserMain/Usermain.c'))
    mainbody=func(main,'main'); loop=re.search(r'while\s*\(1\)',mainbody)
    body=block(mainbody,loop.start())
    if hal:
        h=read(b/'Core/Inc/main.h')
        pins='\n'.join(re.findall(r'^#define (?:LED\d|YLED\d|KEY\d)_[^\n]+',h,re.M))
        pins += '\n'
        gpio=read(b/'Core/Src/gpio.c'); init=func(gpio,'MX_GPIO_Init')
        globals_=main.split('/* USER CODE BEGIN 0 */',1)[1].split('/* USER CODE END 0 */',1)[0]
    else:
        pins=''; init=func(main,'LEDKEY_Init')
        globals_='\n'.join(line for line in main.splitlines() if re.match(r'(static KeyFilter|uint8_t Index|static volatile uint32_t key_millis)',line))
    header=''
    if name!='teacher_hal': header=read(b/('Core/Inc/key_filter.h' if hal else 'UserMain/key_filter.h'))
    test=runner.replace('REQUIRE_DARK','assert((odr[GPIOB]&255U)==255U);' if a.require_safe_start else '') if name=='teacher_hal' else keytest.replace('SET_TICK',('tick' if hal else 'key_millis')+'=0xfffffff0U+elapsed;')
    test=test.replace('REQUIRE_SAFE','assert(simulated_low_enable==0U);' if a.require_safe_start else '')
    source=common+pins+header+globals_+'\nstatic void init_gpio(void) {\n'+init+'\n}\nstatic void app_step(void) {\n'+body+'\n}\n'+test
    c=a.out/(name+'_application.c');c.write_text(source)
    exe=a.out/(name+'_application_host')
    cmd=['gcc','-std=c99','-Wall','-Wextra','-Werror','-Wno-unused-variable','-Wno-unused-function','-pedantic','-fsanitize=undefined,bounds','-fno-sanitize-recover=all','-O2',str(c),'-o',str(exe)]
    r=subprocess.run(cmd,text=True,capture_output=True); (a.out/(name+'_compile.log')).write_text(' '.join(cmd)+'\n'+r.stdout+r.stderr)
    record={'project':name,'compile_exit':r.returncode}
    if r.returncode==0:
        r=subprocess.run([str(exe)],text=True,capture_output=True,timeout=10)
        (a.out/(name+'_run.log')).write_text(r.stdout+r.stderr)
        record.update(run_exit=r.returncode,stdout=r.stdout,stderr=r.stderr)
    if exe.exists(): exe.unlink()
    records.append(record)
report={'scope':'Host execution of exact application loop and GPIO initialization excerpts with GPIO clocks, direction and pull configuration checked against explicit mocks; delay and time inputs mocked. NOT ARM build, device simulation, electrical model or board test.','require_safe_start':a.require_safe_start,'sources_sha256':sources,'checks':records,'all_pass':all(x.get('run_exit')==0 for x in records),'clock_warning':'The test supplies time directly. It does not simulate HAL_Delay, interrupt delivery, oscillator lock, GPIO voltage or real elapsed time.'}
(a.out/'application_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if report['all_pass'] else 1)
