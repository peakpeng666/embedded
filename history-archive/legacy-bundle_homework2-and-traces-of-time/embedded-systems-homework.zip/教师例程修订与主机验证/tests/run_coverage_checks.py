#!/usr/bin/env python3
"""Negative host tests in temporary copies, proving selected bad edits are detected.
Never modifies supplied projects; not MCU/electrical simulation or target build.
"""
from pathlib import Path
import argparse,json,shutil,subprocess,tempfile,sys
from project_clock_config import read_all,clock_case
B=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--projects',type=Path,default=B/'verified_projects');p.add_argument('--out',type=Path,default=B/'results/coverage');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
cases=[
 ('led_output_changed_to_input','teacher_hal','Core/Src/gpio.c','GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;','GPIO_InitStruct.Mode = GPIO_MODE_INPUT;','output_mask'),
 ('hal_key_pullup_removed','teacher_hal02','Core/Src/gpio.c','GPIO_InitStruct.Pull = GPIO_PULLUP;','GPIO_InitStruct.Pull = GPIO_NOPULL;','pullup_mask'),
 ('std_key_pullup_removed','teacher_spl02','UserMain/Usermain.c','GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;','GPIO_InitStructure.GPIO_PuPd = 0;','pullup_mask'),
 ('gpio_clock_removed','teacher_hal','Core/Src/gpio.c','__HAL_RCC_GPIOB_CLK_ENABLE();','/* deliberately omitted in temporary negative test */','clock_enabled')]
records=[]
with tempfile.TemporaryDirectory(prefix='embedded-negative-host-') as d:
 d=Path(d)
 for name,profile,rel,old,new,expected_error in cases:
  dst=d/name;shutil.copytree(a.projects,dst)
  f=dst/profile/rel;text=f.read_text();assert old in text;f.write_text(text.replace(old,new))
  out=a.out/name
  r=subprocess.run([sys.executable,str(B/'tests/run_application_checks.py'),'--projects',str(dst),'--require-safe-start','--out',str(out)],capture_output=True,text=True,timeout=30)
  (a.out/(name+'.log')).write_text('Expected host assertion failure for '+profile+'\nEXIT='+str(r.returncode)+'\n'+r.stdout+r.stderr)
  report=json.loads((out/'application_results.json').read_text());check=next(x for x in report['checks'] if x['project']==profile)
  detected=r.returncode!=0 and check['compile_exit']==0 and check.get('run_exit')!=0 and expected_error in check.get('stderr','')
  records.append({'mutation':name,'project':profile,'detection_expected':True,'detected':detected,'host_compile_exit':check['compile_exit'],'host_run_exit':check.get('run_exit'),'assertion_contains':expected_error})
 dst=d/'wrong_clock';shutil.copytree(a.projects,dst)
 f=dst/'teacher_spl02/UserMain/stm32f4xx.h';text=f.read_bytes();old=b'((uint32_t)8000000)';assert old in text;f.write_bytes(text.replace(old,b'((uint32_t)25000000)',1))
 config=read_all(dst)['teacher_spl02'];case=clock_case('temporary bad HSE constant',config)
 intended=json.loads((B/'revision_manifest.json').read_text())['effective_clock']['teacher_spl02']
 actual={k:config[k] for k in intended};detected=actual!=intended and not case['within_checked_clock_limits']
 records.append({'mutation':'std_HSE_constant_changed_to_25MHz_M8_retained','detection_expected':True,'detected':detected,'source_configuration':actual,'clock_limits':case})
report={'scope':'Host-only mutation sensitivity; deliberate errors in temporary copies. Expected failures are success of the negative checks, not faults in supplied final sources.','checks':records,'all_expected_failures_detected':all(x['detected'] for x in records)}
(a.out/'coverage_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if report['all_expected_failures_detected'] else 1)
