/* Host logic test only: no HAL, CPU, GPIO, RCC or SysTick emulation. */
#include <assert.h>
#include <stdio.h>
#include "key_filter.h"
static unsigned feed(KeyFilter *k, uint8_t raw, uint32_t start, unsigned count)
{
    unsigned i, events = 0;
    for (i=0; i<count; ++i) events += KeyFilter_Update(k,raw,start+i);
    return events;
}
int main(void)
{
    KeyFilter k = KEY_FILTER_INITIALIZER;
    unsigned events = 0;
    assert(feed(&k,1U,0U,100U)==0U); /* released */
    assert(feed(&k,0U,100U,10U)==0U); /* short disturbance */
    assert(feed(&k,1U,110U,30U)==0U);
    events += feed(&k,0U,140U,5U);
    events += feed(&k,1U,145U,3U);
    events += feed(&k,0U,148U,5U);
    events += feed(&k,1U,153U,2U);
    events += feed(&k,0U,155U,2000U);
    assert(events==1U); /* bouncing press + long hold */
    assert(feed(&k,1U,2155U,5U)==0U);
    assert(feed(&k,0U,2160U,5U)==0U); /* release bounce cannot rearm */
    assert(feed(&k,1U,2165U,30U)==0U);
    assert(feed(&k,0U,2195U,100U)==1U); /* second deliberate press */
    k=(KeyFilter)KEY_FILTER_INITIALIZER;
    assert(feed(&k,0U,0xfffffff0U,40U)==1U); /* tick rollover */
    k=(KeyFilter)KEY_FILTER_INITIALIZER;
    assert(feed(&k,0U,0U,100U)==1U); /* held at startup */
    puts("PASS: release, short glitch, press bounce, long hold, release bounce, second press, uint32 wrap, held-at-startup");
    return 0;
}
