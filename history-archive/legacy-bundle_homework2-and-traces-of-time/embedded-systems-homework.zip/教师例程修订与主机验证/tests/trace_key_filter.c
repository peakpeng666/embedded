#include <stdio.h>
#include <inttypes.h>
#include "key_filter.h"
int main(void)
{
    KeyFilter key = KEY_FILTER_INITIALIZER;
    uint32_t now;
    unsigned raw;
    while (scanf("%" SCNu32 " %u", &now, &raw) == 2) {
        unsigned event = KeyFilter_Update(&key,(uint8_t)raw,now);
        printf("%" PRIu32 ",%u,%u,%u\n",now,raw,event,(unsigned)key.stable);
    }
    return 0;
}
