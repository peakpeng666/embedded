; Standalone ARMASM educational example for Cortex-M4 Thumb.
; Not compiled for an MCU in this review. Replace the video Test.s only in a COPY.
; Startup must branch to __main. Do not link alongside a C runtime __main.
; This debugger exercise intentionally exposes R5/R6/R7 and is not an AAPCS C API.
        AREA    Test, CODE, READONLY
        THUMB
        ENTRY
        EXPORT  __main
__main
        MOVS    R0, #50
        MOVS    R1, #101
        BL      func01
        BL      func02
stop
        B       stop            ; prevents fall-through into function bodies
func01
        MOVS    R5, #5
        MOVW    R3, #0x233
        ADD     R5, R5, R3       ; R5 = 0x238
        BX      LR
func02
        MOVS    R7, #8
loop7
        CBZ     R7, init6
        NOP
        SUBS    R7, R7, #1
        B       loop7
init6
        MOVS    R6, #7
loop6
        CBZ     R6, finish
        NOP
        SUBS    R6, R6, #1
        B       loop6
finish
        BX      LR
        END
