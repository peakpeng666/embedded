from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).parent.parent/'讲课视频学习索引/supplement_assets'
t=np.linspace(0,4,4001)
fig,ax=plt.subplots(4,1,figsize=(9,5.5),layout='constrained')
for a,delta,label in zip(ax[:3],[.5,.2,1],['HAL video: 1 Hz (500 ms flips)','SPL video: 2.5 Hz (200 ms flips)','HAL archive: 0.5 Hz (1000 ms flips)']):
 y=(np.floor((t+1e-7)/delta).astype(int)%2)
 a.step(t,y,where='post',color='#205b87');a.set_yticks([0,1]);a.set_ylim(-.2,1.2);a.set_xlim(0,4);a.set_title(label,loc='left',fontsize=10);a.grid(alpha=.2)
ax[2].set_xlabel('Time (s); phase normalized for comparison')
indices=np.arange(65525,65546)
old=(indices&65535)%5==0;new=(indices%5)==0
ax[3].plot(indices,old.astype(int),'o-',label='16-bit index % 5 (original)',color='#b54332')
ax[3].plot(indices,new.astype(int)-.1,'x--',label='Explicit modulo-5 counter',color='#205b87')
ax[3].set_ylim(-.3,1.35);ax[3].set_yticks([0,1]);ax[3].ticklabel_format(useOffset=False,style='plain');ax[3].set_xlabel('Loop index; each step nominally 100 ms');ax[3].set_title('Adjacent triggers at 65535 and 65536 after uint16 wrap',loc='left',fontsize=10);ax[3].legend(fontsize=8,loc='upper left');ax[3].grid(alpha=.2)
fig.suptitle('Ideal code-derived timing, not measured waveforms',fontsize=12)
fig.savefig(p/'theoretical_timing.png',dpi=180);fig.savefig(p/'theoretical_timing.svg');plt.close(fig)
