"""Host-only semantic checks; not an MCU emulator or target build."""
from pathlib import Path
import json
from fractions import Fraction
out=Path(__file__).parent
checks=[]
def check(name,condition,details):
 assert condition,name
 checks.append(dict(name=name,passed=True,details=details))
check('clock_168',Fraction(8,8)*336/2==168,'MHz; PLLQ4=84 exceeds75; Q7=48')
check('clock_167_5',Fraction(25,20)*268/2==Fraction(335,2),'MHz; PLLQ4=83.75 exceeds75')
check('periods',[1/(2*x) for x in [.5,.2,1]]==[1,2.5,.5],'Hz from flip intervals in seconds')
old=[i for i in range(65540) if (i&0xffff)%5==0]
check('uint16_wrap_counterexample',65535 in old and 65536 in old,'100ms adjacent flips at indices65535,65536')
c=0;new=[]
for i in range(200000):
 if c==0:new.append(i)
 c=(c+1)%5
check('mod5_fixed_counter',all(b-a==5 for a,b in zip(new,new[1:])),f'{len(new)} flips in200000 iterations')
command=(0x00b0<<16)|0x0040
for odr in range(65536):
 got=(odr&~(command>>16))|(command&0xffff)
 expected=(odr&~0x00f0)|0x0040
 assert got==expected
check('BSRR_all_ODR',True,'65536 initial states, PA7..PA4=0100 (PA6=1; PA4/PA5/PA7=0), other bits preserved')
subs=cbz=0
for reg in [8,7]:
 while True:
  cbz+=1
  if reg==0:break
  reg-=1;subs+=1
check('sequential_loops',subs==15 and cbz==17,dict(subtractions=subs,zero_tests=cbz))
check('func01',5+0x233==0x238,'R5 arithmetic only')
pc='main';lr=None;trace=[]
for target,ret in [('func01','call2'),('func02','stop')]:
 lr=ret;pc=target;trace.append(pc);pc=lr;trace.append(pc)
check('explicit_stop',pc=='stop',trace)
result=dict(scope='Host Python mathematical/control-flow model only. No target compile, hardware, or peripheral emulator.',checks=checks)
(out/'semantic_check_results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print(json.dumps(result,indent=2,ensure_ascii=False))
