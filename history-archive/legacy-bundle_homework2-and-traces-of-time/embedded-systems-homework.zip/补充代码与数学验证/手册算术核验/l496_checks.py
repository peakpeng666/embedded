"""DS11585 Rev20 numerical consistency checks; no target build or hardware access."""
import json, math
from pathlib import Path
out=[]
def check(name, got, expected, note):
    passed=math.isclose(got,expected,rel_tol=1e-10,abs_tol=1e-10)
    assert passed,(name,got,expected)
    out.append(dict(name=name,result=got,expected=expected,passed=passed,note=note))
check('ADC minimum sample time ns',2.5/80e6*1e9,31.25,'PDF185-186, 80MHz, fast channel; PDF42 says 18.75ns')
check('ADC 12-bit minimum total time ns',(2.5+12.5)/80e6*1e9,187.5,'PDF185; excludes trigger latency')
check('ADC maximum 12-bit fast-channel MSPS',80/(2.5+12.5),16/3,'PDF184-186')
check('ADC maximum 12-bit slow-channel MSPS',80/(6.5+12.5),80/19,'PDF184-187')
check('LQFP100 L minimum inches rounded',round(.45/25.4,4),.0177,'PDF262 incorrectly prints 0.177 in; mm value and PDF269 control')
check('16-bit PSC maximum divider',2**16,65536,'PDF49 prescaler-factor ceiling; this is not counter width')
cal1,cal2,raw,vdda=1040.,1380.,1100.,3.3
normalized=raw*vdda/3.0
check('hypothetical calibrated temperature C',30+(normalized-cal1)*100/(cal2-cal1),80.,'Mathematical illustration only; hypothetical calibration counts, not chip measurements')
check('hypothetical temperature if voltage normalization omitted C',30+(raw-cal1)*100/(cal2-cal1),47.64705882352941,'Shows why PDF43 3.0V factory reference matters; not a measured sensor error')
result={'scope':'host arithmetic checks only, not Keil build, board test, ADC validation, or datasheet certification','tests':out,'all_passed':all(x['passed'] for x in out)}
Path(__file__).with_name('l496_check_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
