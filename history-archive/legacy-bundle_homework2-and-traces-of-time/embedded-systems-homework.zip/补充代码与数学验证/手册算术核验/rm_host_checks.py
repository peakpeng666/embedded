"""Host-only arithmetic checks. No MCU memory access, compilation or hardware use."""
import json
from pathlib import Path
assert [0x24+0x18*s for s in (0,1,7)] == [0x24,0x3c,0xcc]
assert (1<<7)|(1<<6) == 0xc0
assert 0x1fff0000+30*1024-1 == 0x1fff77ff
assert [0x104+8*(n-1) for n in range(1,5)]==[0x104,0x10c,0x114,0x11c]
assert 21-9+1==13
assert 0x2a==42 and 0x2b==43
wrong=[]
for n in range(4096):
 assert (n>>2)+bool(n&3)==(n+3)//4
 old=(n>>2)+bool(n&2)
 if old!=(n+3)//4:wrong.append(n)
assert len(wrong)==1024
wwdg=1000*4096*8*64/24_000_000
assert abs(wwdg-87.38133333333333)<1e-10
result={'kind':'host integer/arithmetic assertions only','passed':True,'wwdg_ms':wwdg,'usb_counts_checked':4096,'old_formula_counterexamples':len(wrong),'target_build':False,'mcu_simulation':False,'hardware_test':False}
Path(__file__).with_name('rm_host_check_results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
