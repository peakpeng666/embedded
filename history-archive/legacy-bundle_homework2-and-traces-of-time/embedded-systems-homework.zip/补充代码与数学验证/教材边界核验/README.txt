这些是独立编写的有界主机反例，不运行课本或归档内的未知可执行文件。
运行方法（Python3，GCC/G++）：
python course_logic_checks.py
python algorithm_counterexamples.py
python 旧C教材/run_checks.py

第一项20个STM32数学/边界检查；第二项11个算法反例；第三项C11、C++17最小演示及6个Python模型。旧C的strncpy截断警告是故意暴露该规则，保留预期警告；不是无警告证明。编译产生的主机临时可执行文件用毕清理，不随包交付。

所有结论仅覆盖列出的表达式与有限用例，未定义行为案例只作语言规则和逻辑边界分析，不能用于证明整体固件、MCU外设或实际板卡已通过验证。
