# Independent minimal models of individual printed expressions; not original book code execution.
import json,math,itertools
checks=[]
def add(name,page,observed,expected):
 checks.append(dict(name=name,pdf_page=page,observed=observed,expected=expected,defect_reproduced=observed!=expected))
# Page 321 predicate loop omitted n<2 check
n=1;book_prime=all(n%i for i in range(2,int(math.sqrt(n))+1));add('prime_input_one',321,book_prime,False)
# PDF342 mathematical exact count and binary64 roundoff
exact=2**64-1;add('double_cannot_preserve_wheat_integer',342,int(float(exact)),exact)
# PDF372 printed answer fails specified process; independent exhaustive search

def fish(n):
 for i in range(5):
  if n<6 or n%5!=1:return False
  n=(n-1)*4//5
 return True
add('fish_printed_3906',372,fish(3906),True)
least=next(n for n in range(6,100000) if fish(n));assert least==3121
# page428 strlen ciphertext would see length0 after XOR
cipher=bytes([ord('A')^ord('A')]);c_strlen=len(cipher.split(b'\0')[0]);add('xor_c_string_cipher_length',428,c_strlen,1)
# page469 min insertion against previous top instead of previous min
st=[];mins=[]
for x in [1,5,3]:
 mv=x if not st or x<st[-1] else mins[-1];st.append(x);mins.append(mv)
add('min_stack_push_1_5_3',469,mins[-1],min(st))
# page453 only examines7 of10; changed final datum exposes incorrect count
arr=[13,9,5,10,17,7,20,11,3,99];add('max_array_length_argument',453,max(arr[:7]),max(arr))
# page456/457 direct write of current run over previous maximum
s='00010';t0=t1=b0=b1=0
for i,ch in enumerate(s):
 prev=s[i-1] if i>0 else '\0' # isolated independently from its separate out-of-bounds read
 if ch=='0':
  if prev=='1':
   if t1>b1:b1=t1
   t1=0
  t0+=1;b0=t0
 if ch=='1':
  if t0>b0:b0=t0
  if prev=='0':t0=0
  t1+=1;b1=t1
add('longest_zero_run_overwritten',456,b0,3)
# page235 convergence delta computed after assigning previous=current
old=.5;new=.3;old=new;add('trapezoid_delta_order',235,abs(old-new),.2)
# page245 stated extremum: y=-x^2+11x-10 at5.5
add('parabola_value_printed',245,2.025,-5.5**2+11*5.5-10)
#page384 unwanted4 red allowed despite original maximum3
book=[(r,y,g) for r in range(5) for y in range(5) for g in range(8) if r+y+g==8]
valid=[(r,y,g) for r in range(4) for y in range(4) for g in range(7) if r+y+g==8]
add('three_ball_loop_bounds',384,len(book),len(valid))
#page304 amicable partner of220
proper=lambda n:sum(i for i in range(1,n) if n%i==0)
add('amicable_partner_printed',304,204,proper(220))
assert all(x['defect_reproduced'] for x in checks)
print(json.dumps({'method':'Independent Python mathematical counterexamples, no original executables or STM32 runtime','checks':checks,'fish_minimum':least},ensure_ascii=False,indent=2))
