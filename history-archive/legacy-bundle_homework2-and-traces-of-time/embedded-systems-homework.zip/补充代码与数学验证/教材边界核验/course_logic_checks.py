"""Host-only mathematical/logic checks. Does not execute imported firmware or touch hardware."""
import json, math
from pathlib import Path
out=[]
def check(name,condition,detail):
    assert condition,name
    out.append({'check':name,'passed':True,'detail':detail})
clock=84_000_000
check('PWM_STD_2kHz',clock/((99+1)*(419+1))==2000,'PSC99 ARR419')
check('PWM_PDF_HAL_500Hz',clock/((19+1)*(8399+1))==500,'PDF says PSC19 ARR8399')
check('PWM_ARCHIVE_HAL_333Hz',math.isclose(clock/((29+1)*(8399+1)),1000/3),'Archive tim.c uses PSC29')
check('heartbeat_toggle_1s',1/(2*1.0)==0.5,'One toggle every second gives 0.5Hz full cycle')
check('SysTick_reload',168_000_000//1000-1==167999,'ticks=168000; LOAD=ticks-1')
goodmask=(3<<(2*2))|(3<<(3*2));badmask=(3<<2)|(3<<3)
check('MODER_masks_differ',goodmask==0xf0 and badmask==0x1c,{'good':hex(goodmask),'old':hex(badmask)})
baseline=0xffffffff;bad=(baseline&~badmask)|(2<<4)|(2<<6);good=(baseline&~goodmask)|(2<<4)|(2<<6)
check('MODER_preserves_other_fields',(good&~goodmask)==(baseline&~goodmask) and (bad&~goodmask)!=(baseline&~goodmask),'Old mask alters PA1')
check('LE_equal_counterexample',((1==1) or (0!=0)) and not ((1==1) and (0!=0)),'Equal operands: Z1 N0 V0')
vsense=0.885;old=(vsense-.76)/2.5+25;new=(vsense-.76)/.0025+25
check('temperature_slope_units',math.isclose(old,25.05) and math.isclose(new,75),'Vsense0.885V: 25.05 vs75 degrees C using typical constants')
check('temperature_STD_integer_loss',int(885/1000)==0,'Integer millivolts/1000 truncates before floating expression')
check('Flash_16bit_slot_shortfall',(16*1024*1024-4096)//128==131040 and 131040>65535,'16-bit index covers fewer than available128B slots')
check('Flash_latest_when_empty',4096+(0-1)*128==3968,'NN=0 underflows logical record index into protected first4KiB')
check('LCD_non_square_stride',1*3+0!=1*2+0,'2wide x3high: old row index i*height differs from i*width')
check('new2_digit_mask',0x0400f!=0x0400 and (0x0400f&0xff)!=0,'Third digit select also modifies segment bits and wrong port bit')
cc1,cc2=1000,1200
old_second=(1*0xffffffff+cc2)&0xffffffff
check('capture_normal_period_off_by_one',old_second-cc1==199 and ((cc2-cc1)&0xffffffff)==200,'Old index*0xFFFFFFFF loses one tick even without wrap')
adc_scan_us=(4*(56+12)+3*(112+12))/21_000_000*1e6
serial_us=60*10/115200*1e6
check('ADC_UART_rate_mismatch',serial_us>100*adc_scan_us,{'adc_scan_us':adc_scan_us,'60byte_uart_us':serial_us})
check('CAN_prescaler_12',42_000_000/(12*(1+7+6))==250000,'CAN_Prescaler=12; BRP register11')
check('CAN_status_pending_not_success','Pending'!='Failed','while(status==Failed) exits immediately on Pending')
check('PWM_duty_polarity',210/(839+1)==.25,'PWM1 high-active25%, inverse/low-active75%')
check('New2_scan_period',4*5/100==.2,'SysTick100Hz, Delay5=50ms, whole4digit scan200ms=5Hz')
Path(__file__).with_name('logic_checks_results.json').write_text(json.dumps({'scope':'Host-only models; no firmware build, simulator or hardware execution','checks':out},ensure_ascii=False,indent=2))
print(f'{len(out)} host-only checks passed')
