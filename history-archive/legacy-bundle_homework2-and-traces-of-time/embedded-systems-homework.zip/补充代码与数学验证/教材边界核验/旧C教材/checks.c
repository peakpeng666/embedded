/* Independently written, bounded demonstrations. No undefined-behavior cases executed. */
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <stdlib.h>
#include <assert.h>
union Value { int i; float f; };
static union Value echo_union(union Value x) { return x; }
enum Day { SUN, MON, TUE };
struct Layout { char c; int i; char z; };
int main(void) {
  char a[4]={'x','x','x','x'}; int n=sscanf("ABC", "%3c", a);
  assert(n==1 && a[0]=='A' && a[1]=='B' && a[2]=='C' && a[3]=='x');
  printf("scanf_3c=%c%c%c; fourth=%c\n", a[0],a[1],a[2],a[3]);
  int x=0,y=0; n=sscanf("1-2", "%d  %d", &x,&y);
  assert(n==2 && x==1 && y==-2); printf("scanf_spaces=%d,%d\n",x,y);
  char b[4]={'x','x','x','x'}; strncpy(b,"ABC",2);
  assert(b[0]=='A' && b[1]=='B' && b[2]=='x'); printf("strncpy_2=%c%c%c\n", b[0],b[1],b[2]);
  union Value v={.i=7},w=echo_union(v); assert(w.i==7);
  enum Day d=2; assert(d==TUE); printf("union_copy=%d; enum_int=%d\n",w.i,d);
  printf("layout_size=%zu; members_sum=%zu; i_offset=%zu\n",sizeof(struct Layout),sizeof(char)*2+sizeof(int),offsetof(struct Layout,i));
  FILE *in=tmpfile(), *out=tmpfile(); assert(in && out);
  assert(fputc('A',in)!=EOF); rewind(in);
  while(!feof(in)) { int c=fgetc(in); assert(fputc(c,out)!=EOF); }
  assert(ftell(out)==2); rewind(out); x=fgetc(out); y=fgetc(out);
  assert(x=='A' && y==(unsigned char)EOF); printf("feof_copy=%02X,%02X\n",x,y);
  fclose(in); fclose(out);
  char name[20]; float score=0; n=sscanf("Li Li 67.5", "%19s%f",name,&score);
  assert(n==1); printf("spaced_name_conversions=%d\n",n);
  return 0;
}
