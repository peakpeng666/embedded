#include <cassert>
#include <iostream>
#include <climits>
static inline int maximum(int a,int b,int c){ if(b>a)a=b;if(c>a)a=c;return a; }
static int constructors=0;
struct Base { Base(){++constructors;} };
struct Child:Base { Child(){} };
union PrivateUnion { private: int v; public: explicit PrivateUnion(int n):v(n){} int get()const{return v;} };
int main(){int i=7,j=10,k=25;int result=maximum(i,j,k);assert(i==7&&result==25);
std::cout<<"inline_result="<<result<<"; caller_i="<<i<<'\n';
Child c; (void)c;assert(constructors==1);std::cout<<"base_constructed="<<constructors<<'\n';
PrivateUnion u(3);assert(u.get()==3);int *a=new int[3]{1,2,3};assert(a[2]==3);delete[] a;
std::cout<<"union_private_and_new_array_init=OK\n";
if(INT_MIN < -40001){int old=maximum(-40000,-40001,-32768);assert(old==-32768);std::cout<<"default_sentinel_bad="<<old<<"; correct=-40000\n";}
}
