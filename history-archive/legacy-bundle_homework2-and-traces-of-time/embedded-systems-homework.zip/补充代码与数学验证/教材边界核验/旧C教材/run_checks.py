import json, math, subprocess, hashlib, tempfile
from pathlib import Path
p=Path(__file__).resolve().parent
results=[]
temporary = tempfile.TemporaryDirectory(prefix='embedded-c-examples-')
for src,compiler,mode in [('checks.c','gcc','c11'),('checks.cpp','g++','c++17')]:
    exe=Path(temporary.name)/(src+'.out'); build=subprocess.run([compiler,'-std='+mode,'-Wall','-Wextra','-Werror','-Wno-error=stringop-truncation','-O2',str(p/src),'-o',str(exe)],capture_output=True,text=True)
    assert build.returncode==0,build.stderr
    run=subprocess.run([str(exe)],capture_output=True,text=True,timeout=10);assert run.returncode==0,run.stderr
    results.append({'kind':'safe_independent_compiled_demonstration','source':src,'sha256':hashlib.sha256((p/src).read_bytes()).hexdigest(),'compiler':subprocess.check_output([compiler,'--version'],text=True).splitlines()[0],'mode':mode,'compiler_diagnostics':build.stderr,'output':run.stdout,'exit_code':run.returncode})
temporary.cleanup()
checks=[]
def check(name,actual,expected,pages):
    assert actual==expected,(name,actual,expected)
    checks.append({'name':name,'actual':actual,'expected':expected,'source_pdf_pages':pages,'pass':True})
check('prime_1_book_loop_accepts',2>=int(math.sqrt(1))+1,True,[128])
check('reverse_uninitialized_first_index',list(range(9,0,-1))[0] not in range(9),True,[133])
check('sphere_coefficient_ratio',(3/4)/(4/3),0.5625,[198])
f=lambda x:x*x*x-5*x*x+16*x-80
x1,x2=2.,6.;y1,y2=f(x1),f(x2);x=(x1*y2-x2*y1)/(y2-y1);y=f(x)
check('false_position_branch_disagrees',(x*y1>0)!=(y*y1>0),True,[167])
check('three_colour_combinations_vs_permutations',(math.comb(5,3),math.perm(5,3)),(10,60),[303,304])
from types import SimpleNamespace
head=None; p1=head; p0=SimpleNamespace(num=1,next=None)
if head is None:
    head=p0; p0.next=None
else:
    while p0.num>p1.num and p1.next is not None:
        p2=p1; p1=p1.next
try:
    would_prepend=(p0.num<=p1.num)
    null_reached=False
except AttributeError:
    null_reached=True
check('empty_insert_after_else_reaches_null_test',null_reached,True,[292,294])
results.append({'kind':'bounded_python_logic_models','checks':checks,'null_note':'The null case is a control-flow proof/model; no NULL dereference executed.'})
(p/'check_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False,indent=2))
