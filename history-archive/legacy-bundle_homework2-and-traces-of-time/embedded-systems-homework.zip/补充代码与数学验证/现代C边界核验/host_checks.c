/* Host-only C semantics checks. Not firmware, simulator, ABI or hardware validation. */
#include <assert.h>
#include <float.h>
#include <inttypes.h>
#include <limits.h>
#include <math.h>
#include <stddef.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
struct payload { size_t length; unsigned char data[]; };
static bool prime_u32(uint32_t n) {
    if (n < 2) return false;
    for (uint32_t d=2; d <= n/d; ++d)
        if (n%d == 0) return false;
    return true;
}
static unsigned check_digit(unsigned total) { return (10u-total%10u)%10u; }
int main(void) {
    /* Brace elision is legal C11, although a style warning is reasonable. */
    struct { char c; struct { int x; }; } t = {'x', 1};
    assert(t.c=='x' && t.x==1);
    assert(sizeof(struct payload)>=sizeof(size_t));
    int a[]={2,3,5}, out[3], *p=a+3; size_t i=0;
    while (p != a) out[i++]=*--p;
    assert(i==3 && out[0]==5 && out[2]==2);
    assert(!prime_u32(0) && !prime_u32(1) && prime_u32(2));
    assert(prime_u32(UINT32_C(2147483647)) && !prime_u32(UINT32_MAX));
    for(unsigned total=0;total<300;total++) {
        unsigned digit=check_digit(total);
        assert(digit<=9 && (total+digit)%10==0);
    }
    int old_formula_at_zero=9-((0-1)%10);
    assert(old_formula_at_zero==10);
    atomic_int counter=0;
    /* Deliberate legal schedule: two atomic loads, then two atomic stores. */
    int read_a=atomic_load(&counter), read_b=atomic_load(&counter);
    atomic_store(&counter,read_a+1); atomic_store(&counter,read_b+1);
    assert(atomic_load(&counter)==1); /* logical lost update, no C data race */
    int old=atomic_fetch_add(&counter,4);
    assert(old==1 && atomic_load(&counter)==5);
    assert(trunc(-1.9)==-1.0 && floor(-1.9)==-2.0);
    assert(round(1.2)==1.0 && round(-1.5)==-2.0);
    assert(FLT_RADIX==2 && logb(3.0)==1.0);
    int e; double f=frexp(-12.0,&e);
    assert(f==-0.75 && e==4);
    printf("host-only: reverse=5,3,2; prime checks=pass; UPC zero: book=%d fixed=%u\n",old_formula_at_zero,check_digit(0));
    printf("host-only: split atomic result=1; fetch_add old=%d new=%d; frexp(-12)=%.2f*2^%d\n",old,atomic_load(&counter),f,e);
    printf("host-only ABI: CHAR_BIT=%d int=%zu long=%zu pointer=%zu; not F407 measurements\n",CHAR_BIT,sizeof(int),sizeof(long),sizeof(void*));
    return 0;
}
