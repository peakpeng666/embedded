/* C11 hosted-library demonstration only. Fail fast on synchronization errors. */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <threads.h>
static mtx_t lock;
static cnd_t changed;
static int ready, values[2];
struct job { int index, result; };
static void checked(int status) {
    if(status!=thrd_success) { fputs("host thread API failed\n",stderr); abort(); }
}
static int worker(void *p) {
    const struct job *j=p;
    int local=j->result;  /* real computation would happen in local storage */
    checked(mtx_lock(&lock));
    values[j->index]=local;
    ++ready;
    checked(cnd_broadcast(&changed));
    while (ready!=2) checked(cnd_wait(&changed,&lock));
    int result=values[0]+values[1];
    checked(mtx_unlock(&lock));
    return result;
}
int main(void) {
    checked(mtx_init(&lock,mtx_plain));
    checked(cnd_init(&changed));
    struct job jobs[2]={{0,12000},{1,306}};
    thrd_t ids[2]; int results[2];
    checked(thrd_create(&ids[0],worker,&jobs[0]));
    checked(thrd_create(&ids[1],worker,&jobs[1]));
    checked(thrd_join(ids[0],&results[0]));
    checked(thrd_join(ids[1],&results[1]));
    assert(results[0]==12306 && results[1]==12306);
    cnd_destroy(&changed); mtx_destroy(&lock);
    puts("host-only C11 threads: both results=12306; all API returns checked");
    return 0;
}
