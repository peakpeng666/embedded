#include <stdio.h>
void example(void) { long long counter=0; printf("%d\n",counter); }
