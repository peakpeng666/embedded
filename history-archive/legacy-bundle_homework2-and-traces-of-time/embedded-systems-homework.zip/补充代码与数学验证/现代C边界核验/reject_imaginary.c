#include <complex.h>
double complex example(void) { return .3+.5i; }
