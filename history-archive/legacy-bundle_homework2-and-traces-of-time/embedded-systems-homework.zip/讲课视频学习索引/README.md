# 视频学习索引（2026-10-05逐秒复核版）

27页Word与XeLaTeX PDF：原21页操作索引和13张关键原图，新增6页逐秒覆盖、时钟/代码纠错、理想波形与GIF说明。18:55的SPL数组仍在修订，19:00全逗号；图注已改正。

- video_operation_knowledge_index.md：86个教学事件。旧全音轨1787段ASR阅读与本轮视觉复核分别说明。
- verified_video_review.md：本轮技术结论、时刻及限制。
- coverage/wmv_second_coverage.csv：4654个整数秒的实际PTS、视觉状态、源Drive ID和音画事件对齐。
- coverage/source_video_hashes.json：原媒体大小与SHA256。
- coverage/gif_checkpoints.json：73个GIF整数秒与4个末帧。
- coverage/transition_checkpoints.json：49个0.1秒过渡检查点；短时源片空白不补造。
- coverage/pts_and_tail_audit.json：全原始帧时间戳审计与5个末帧阅读记录；解码审计不等于每个帧都看过。
- supplement_assets：根据代码计算的理想波形，不是实测；生成程序在同包“补充代码与数学验证”。

原WMV与GIF保留原位置，不重复打包。1Hz连续覆盖不等于46524个原始视频帧逐帧阅读；未声称本轮重新转写或逐字重听音轨。没有目标板下载、波形或完整MCU外设仿真证据。
