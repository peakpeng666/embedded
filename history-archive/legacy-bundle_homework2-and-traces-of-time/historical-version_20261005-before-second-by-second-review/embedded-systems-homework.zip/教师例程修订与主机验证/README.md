# 教师例程修订与可复现检查

这是课程原工程的独立修订副本，原件未修改。修订日期：2026-10-04。

**验证级别：主机侧逻辑测试、数学模型、主机GCC语法检查。未完成AC5目标编译、链接、CubeMX重新生成、MCU仿真、烧录或板测。**

## 先选择正确硬件，不能按芯片型号直接互换

| 目录 | 原件 | 所需晶振与引脚 | 改动 |
|---|---|---|---|
| teacher_hal | CH5EX01HAL | 原源码要求HSE8MHz；PE3/PE4 LED，PB0–PB7流水灯 | Q4→Q7；流水每100ms一步，每5步翻转PE3，完整周期名义1Hz |
| teacher_hal02 | CH5EX02HAL | 原源码要求HSE8MHz；PF6低有效按键，PE3/PE4 LED | Q4→Q7；20ms稳定按下沿计数，稳定释放后再允许计数 |
| teacher_spl02 | CH5Ex02STD | 原源码假设HSE25MHz、M25；PF6低有效按键，PE3/PE4 LED | 保留25MHz/M25，修复按键采样与长按重复计数 |

这些不是普中PF9/PE4按键接法。teacher_spl02没有被强行改成8MHz，若目标板实际8MHz，不可原样使用它。工程内“25MHz”是源代码假设，不是已经测得老师实板晶振。使用前核对原理图与晶振，不要直接烧录。

题干要求PE3心跳1Hz、PB0–7顺序流水，未限定流水步长。本修订选择100ms流水步长并每5步翻转PE3，以靠近原STD示例教学节拍；这是一项明确选择，不是新增题干要求。HAL_Delay与执行开销意味着“1Hz”是名义值，不是板测精度。

## 文件用途

- verified_projects/：完整独立源工程副本，保留原库与原工程结构；旧AXF/HEX/对象/构建日志未带入，避免误认为是修订后产物
- replacements/：仅变更文件，便于对照
- patches/：统一diff，方便人工评审
- revision_manifest.json：适用硬件、原源码哈希、变更前后哈希、每项原因
- apply_revision.py：从匹配的原工程创建新副本，不覆盖原目录；输入不匹配则停止
- tests/key_filter.h：与两个按键工程实际使用的逻辑一致，已进行主机C测试
- run_checks.py：可重复的主机测试及可选语法检查
- plot_models.py：可重复计算图，使用matplotlib（可选，原环境已有）
- results/：实际检查日志、JSON结果、CSV合成按键轨迹和PNG/SVG计算图

## 如何复核与应用

直接使用verified_projects中的对应工程；它们仍需在原有Keil/AC5环境执行Rebuild。

若从自己保存的原RAR重建：先解压RAR，使source路径下面直接出现Core/Drivers或UserMain/STM32F4xx_Startup等原始目录，再执行：

```text
python apply_revision.py teacher_hal 原始CH5EX01HAL解包目录 全新目标目录
python apply_revision.py teacher_hal02 原始CH5EX02HAL解包目录 全新目标目录
python apply_revision.py teacher_spl02 原始CH5Ex02STD解包目录 全新目标目录
```

脚本核对全部原C/H/汇编/IOC/uvprojx/uvoptx SHA-256；不匹配时不要强行跳过校验，应先确认版本。目标目录必须不存在且不能位于源目录内部。此脚本不执行任何工程文件，也不调用Keil。

主机检查（Python3 + 主机GCC；没有安装新工具）：

```text
python run_checks.py
python run_checks.py --projects verified_projects
python plot_models.py
```

第三条需要matplotlib；前两条只需要Python标准库和GCC。主机可执行程序仅临时编译我们新写的key_filter测试，不执行用户上传二进制。

## 已实际完成的检查

1. key_filter C逻辑在主机GCC C99、-Wall -Wextra -Werror -pedantic下编译并运行：释放、短毛刺、按下抖动、长按、释放抖动、第二次按下、32位tick回绕、启动时已按住全部通过
2. 1401个合成采样点输入同一C状态机，事件在136ms与920ms各一次；长按不反复计数。CSV与图保留输入、稳定状态和事件，非真实开关采集
3. 三个修改后的main源文件用原工程头文件执行主机gcc -fsyntax-only，退出码均0；仍有64位主机/32位MCU指针宽度相关警告，日志完整保留。STD原始include的usermain.h与文件Usermain.h大小写差异，用临时头文件别名支持Linux检查，未修改Windows项目文件
4. 时钟公式、PLL输入/48支路边界、SysTick LOAD+1复核；8MHz/M25的53.76MHz仅代数值，低于PLL输入范围故不保证锁定
5. 原件全部源码哈希未变，三个完整副本变更文件与replacement哈希一致

**语法检查不验证汇编、ARM ABI、库链接、AC5兼容性、硬件时序或外设。不能据此写“修订工程已编译通过/仿真通过”。**

## 按键行为设计

- 每轮重新读取PF6，原来的“延时后再判断旧值”已去掉
- 候选电平连续稳定至少20ms才被接受；只在稳定高→低时计一次
- 长按不重复；稳定释放后重新使能下一次按下
- 上电默认视为释放；若上电已按住，稳定20ms后计一次
- 20ms是教学设计值；小于该稳定窗口的脉冲不会产生按键事件，实际开关仍应实测调整
- 状态机本身非阻塞，主循环仍沿用原例程HAL_Delay(1)/Delay(1)让步；这不是RTOS方案，名义采样间隔不代表严格1ms
- HAL用HAL_GetTick；STD沿用原1ms SysTick_Handler→TimingDelay_Decrement，在此增加单一volatile毫秒计数，无新中断框架

## 重新生成与构建注意

HAL .ioc的PLLQ字段、IPParameters、48MHz计算显示已同步；Cortex_Div显示改为实际默认HAL时基使用的HCLK。没有运行CubeMX重新生成，IOC可被新版本生成器规范化，须在使用者现有环境再次核对。

CubeMX重新生成前保持代码在USER CODE区；key_filter.h为手写头文件。生成后应再次核main的Q7、时间片、PF6采样与按键helper引用，不能只看图形时钟树。

Keil中打开：
- teacher_hal/CH5EX01HAL/MDK-ARM/CH5EX01HAL.uvprojx
- teacher_hal02/CH5EX02HAL/MDK-ARM/CH5EX02HAL.uvprojx
- teacher_spl02/UserMain/CH5Ex02STD.uvprojx

使用原例程AC5编译器和已安装器件包，保存新的完整Rebuild日志。未经新的日志不能沿用教师原HAL3390或STD1528等代码尺寸作为修订证据。无实体板时可以如实保留构建/仿真受阻记录，不编造GPIO或时钟现象。

## 来源与电气依据

- [CH5EX01HAL原RAR](https://drive.google.com/file/d/1SiaXWNtQBBjrw8Dl70PK68exQ3V929ve/view)
- [CH5EX02HAL原RAR](https://drive.google.com/file/d/1eYPEfxzdqma7slRJ-QxE6-TVGpuicq_G/view)
- [CH5Ex02STD原RAR](https://drive.google.com/file/d/1_Eqqedya6NRjtd38yxUHLNh2EwDwJ3xX/view)
- 原始源工程的厂商版权/许可文字保持原样
- ST DS8626 Rev12表36：PLL输入0.95–2.10MHz，PLL48支路最大75MHz；Q7使336MHz/7=48MHz。实际供电与Flash等待周期也必须符合器件要求

本包与URP项目完全独立。所有图均为教育计算/合成输入，不是示波器图、真实寄存器仿真或硬件测试结果。
