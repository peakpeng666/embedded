"""Educational calculation diagrams. No physical signals or register simulation.
Optional dependency: matplotlib; run_checks.py itself uses standard Python only.
"""
from pathlib import Path
import json,csv
import os
os.environ.setdefault('MPLCONFIGDIR',str(Path('/tmp')/'embedded-mpl-cache'))
os.environ.setdefault('XDG_CACHE_HOME',str(Path('/tmp')/'embedded-font-cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
B=Path(__file__).resolve().parent;R=B/'results'
r=json.loads((R/'test_results.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,2,figsize=(12,5.4),layout='constrained')
fig.suptitle('Clock calculations | Educational model, NOT a hardware measurement',fontsize=15,fontweight='bold')
ax=axes[0];bars=ax.bar(['HAL original\nQ = 4','HAL revision\nQ = 7'],[84,48],color=['#C64937','#287B77'],width=.52)
ax.axhline(75,color='#78481F',linestyle='--',label='DS8626 table 36 maximum: 75 MHz')
ax.bar_label(bars,labels=['84 MHz','48 MHz'],padding=4);ax.set_ylim(0,100);ax.set_ylabel('PLL Q-branch (MHz)');ax.set_title('HSE 8 / M8 × N336');ax.legend(fontsize=9,loc='upper right')
ax=axes[1];bars=ax.bar(['STD intended\nHSE25 / M25','Wrong board\nHSE8 / M25'],[1,.32],color=['#287B77','#C64937'],width=.52)
ax.axhline(.95,color='#78481F',linestyle='--',label='DS8626 table 36 minimum: 0.95 MHz')
ax.bar_label(bars,labels=['1.00 MHz','0.32 MHz'],padding=4);ax.set_ylim(0,1.3);ax.set_ylabel('PLL input (MHz)');ax.set_title('Crystal must match project configuration');ax.legend(fontsize=9,loc='upper right')
fig.text(.50,.015,'53.76 MHz is only an ideal formula result for the wrong-board case; PLL lock is not guaranteed.',ha='center',fontsize=10)
fig.get_layout_engine().set(rect=(0,.065,1,.935))
fig.savefig(R/'clock_calculation.png',dpi=150);fig.savefig(R/'clock_calculation.svg');plt.close(fig)
rows=list(csv.DictReader((R/'key_trace.csv').open()));ts=[int(x['ms']) for x in rows];raw=[int(x['raw']) for x in rows];stable=[int(x['stable']) for x in rows];events=[int(x['ms']) for x in rows if x['event']=='1']
# Original-example timing model: every loop blocks200ms, plus5ms while pressed;
# it rereads only at each loop start and checks the stored old value after5ms.
old=[];t=0
while t<=1400:
    if raw[t]==0:t+=5;old.append(t)
    t+=200
fig,axes=plt.subplots(3,1,figsize=(12,7),sharex=True,layout='constrained')
fig.suptitle('Active-low key | Synthetic input + host C state-machine output',fontsize=15,fontweight='bold')
axes[0].step(ts,raw,where='post',color='#64758B');axes[0].set_ylabel('Raw input');axes[0].set_yticks([0,1],['Pressed','Released']);axes[0].set_ylim(-.15,1.2)
axes[1].step(ts,stable,where='post',color='#287B77');axes[1].scatter(events,[0]*len(events),marker='v',s=95,color='#D58820',zorder=5);axes[1].set_ylabel('Stable input');axes[1].set_yticks([0,1],['Pressed','Released']);axes[1].set_ylim(-.15,1.2);axes[1].set_title('Revision: 20 ms stability; one event per stable press; events at 136 and 920 ms',fontsize=11)
axes[2].eventplot([old,events],lineoffsets=[1,0],colors=['#C64937','#287B77'],linelengths=.55);axes[2].set_yticks([0,1],['Revised C events','Old-code model']);axes[2].set_ylim(-.6,1.6);axes[2].set_xlabel('Synthetic time (ms)');axes[2].set_xlim(0,1400)
for ax in axes:ax.grid(axis='x',alpha=.2)
fig.text(.5,.005,'Teaching model only: no switch measurements, firmware execution, CPU/RCC/GPIO/SysTick simulation or timing-accuracy claim.',ha='center',fontsize=9)
fig.get_layout_engine().set(rect=(0,.05,1,.95))
fig.savefig(R/'key_behaviour.png',dpi=150);fig.savefig(R/'key_behaviour.svg');plt.close(fig)
print('Wrote clock_calculation and key_behaviour PNG/SVG')
