#!/usr/bin/env python3
"""Reproducible HOST ONLY checks. Requires Python3 and host GCC on PATH.
Optional --projects ROOT contains three copies created with apply_revision.py.
No MCU execution, assembler/linker check, board/peripheral simulation or clock measurement.
"""
import argparse,csv,json,subprocess,tempfile,os
from pathlib import Path
B=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--projects',type=Path);a=p.parse_args()
out=B/'results';out.mkdir(exist_ok=True)
records=[]
def run(cmd,name,input=None):
    r=subprocess.run(list(map(str,cmd)),input=input,text=True,capture_output=True)
    (out/(name+'.log')).write_text('$ '+' '.join(map(str,cmd))+'\nEXIT='+str(r.returncode)+'\n'+r.stdout+r.stderr,encoding='utf-8')
    records.append({'check':name,'exit':r.returncode,'kind':'host-only'})
    return r
with tempfile.TemporaryDirectory(prefix='embedded-host-') as t:
    t=Path(t)
    r=run(['gcc','-std=c99','-Wall','-Wextra','-Werror','-pedantic',B/'tests/test_key_filter.c','-o',t/'keytest'],'compile_host_key_test');assert r.returncode==0
    r=run([t/'keytest'],'run_host_key_test');assert r.returncode==0
    r=run(['gcc','-std=c99','-Wall','-Wextra','-Werror','-pedantic',B/'tests/trace_key_filter.c','-o',t/'trace'],'compile_host_trace');assert r.returncode==0
    def raw(ms):
        if 100<=ms<105 or 108<=ms<112 or 116<=ms<700 or 706<=ms<711 or 900<=ms<1200:return 0
        return 1
    inp=''.join(f'{ms} {raw(ms)}\n' for ms in range(1401))
    r=run([t/'trace'],'run_host_trace',inp);assert r.returncode==0
    (out/'key_trace.csv').write_text('ms,raw,event,stable\n'+r.stdout)
    rows=list(csv.DictReader(r.stdout.splitlines(),fieldnames=['ms','raw','event','stable']))
    events=[int(row['ms']) for row in rows if row['event']=='1'];assert events==[136,920],events
    if a.projects:
        root=a.projects.resolve()
        for name in ['teacher_hal','teacher_hal02']:
            b=root/name
            includes=['Core/Inc','Drivers/STM32F4xx_HAL_Driver/Inc','Drivers/STM32F4xx_HAL_Driver/Inc/Legacy','Drivers/CMSIS/Device/ST/STM32F4xx/Include','Drivers/CMSIS/Include']
            cmd=['gcc','-fsyntax-only','-std=c99','-DSTM32F407xx','-DUSE_HAL_DRIVER']+['-I'+str(b/i) for i in includes]+[b/'Core/Src/main.c']
            r=run(cmd,name+'_host_syntax');assert r.returncode==0,r.stderr
        b=root/'teacher_spl02'
        # Original Windows include "usermain.h" differs in case from Usermain.h.
        # A temporary include alias supports Linux parsing; no project source changes.
        (t/'usermain.h').symlink_to(b/'UserMain/Usermain.h')
        cmd=['gcc','-fsyntax-only','-std=c99','-DSTM32F40_41xxx','-DUSE_STDPERIPH_DRIVER','-I'+str(t)]+['-I'+str(b/i) for i in ['UserMain','STM32F4xx_Startup/Include','STM32F4xx_StdPeriph_Driver/inc']]+[b/'UserMain/Usermain.c']
        r=run(cmd,'teacher_spl02_host_syntax');assert r.returncode==0,r.stderr
clock_cases=[{'case':'HAL original HSE8 Q4','hse_MHz':8,'M':8,'N':336,'P':2,'Q':4}, {'case':'HAL revised HSE8 Q7','hse_MHz':8,'M':8,'N':336,'P':2,'Q':7}, {'case':'STD unchanged HSE25 M25','hse_MHz':25,'M':25,'N':336,'P':2,'Q':7}, {'case':'Wrong board HSE8 M25','hse_MHz':8,'M':25,'N':336,'P':2,'Q':7}]
for c in clock_cases:
    c['PLL_input_MHz']=c['hse_MHz']/c['M'];c['VCO_MHz']=c['PLL_input_MHz']*c['N'];c['SYSCLK_ideal_MHz']=c['VCO_MHz']/c['P'];c['PLLQ_ideal_MHz']=c['VCO_MHz']/c['Q'];c['within_pll_input_range']=0.95<=c['PLL_input_MHz']<=2.1;c['within_pll48_upper_bound']=c['PLLQ_ideal_MHz']<=75
assert clock_cases[1]['PLLQ_ideal_MHz']==48 and clock_cases[2]['SYSCLK_ideal_MHz']==168
assert not clock_cases[0]['within_pll48_upper_bound'] and not clock_cases[3]['within_pll_input_range']
ticks=[{'HCLK_Hz':168000000,'divisor':1,'period_ms':1,'LOAD':167999},{'HCLK_Hz':168000000,'divisor':1,'period_ms':10,'LOAD':1679999},{'HCLK_Hz':168000000,'divisor':8,'period_ms':1,'LOAD':20999}]
for c in ticks:assert (c['LOAD']+1)*c['divisor']/c['HCLK_Hz']*1000==c['period_ms']
report={'scope':'Educational calculations + actual host C tests; NOT MCU/peripheral simulation','checks':records,'key_press_events_ms':events,'clock_cases':clock_cases,'systick':ticks,'heartbeat_model':{'step_ms':100,'steps_per_toggle':5,'period_ms':1000,'Hz':1},'warning':'Syntax-only target-source parsing uses host GCC and real project headers, emits pointer-width warnings; excludes assembly, linking, ARM ABI, CubeMX regeneration and hardware behaviour'}
(out/'test_results.json').write_text(json.dumps(report,indent=2))
print('PASS: host key logic, trace, clock/SysTick arithmetic'+(', 3 source syntax-only checks' if a.projects else ''))
print('No MCU build or simulation was performed.')
