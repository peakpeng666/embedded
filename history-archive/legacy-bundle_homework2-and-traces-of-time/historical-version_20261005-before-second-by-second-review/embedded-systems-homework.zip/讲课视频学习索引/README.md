# 视频学习附录

- [核验摘要与作业验收问题](verified_video_review.md)
- [完整操作与知识索引](video_operation_knowledge_index.md)

索引已区分讲课要求、演示选值、中途编辑和最终状态，并列出未能确认的时段。配图13张，均在evidence目录，通过索引相对链接打开。视频原件用摘要中的Drive链接访问，无需在学习包中重复保存。
