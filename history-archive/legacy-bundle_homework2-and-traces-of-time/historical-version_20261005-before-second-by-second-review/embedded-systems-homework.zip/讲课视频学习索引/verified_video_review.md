# 嵌入式讲课视频核验摘要

核验完成：2026-10-04。五段视频均取得原始WMV字节，大小与Drive元数据一致，总时长 **77分32.401秒**。对五段全长音轨作离线中文转录（含VAD静音过滤），逐条阅读1787个转录片段；查看覆盖整个时间轴的165张定间隔采样画面，并对关键配置/错误/代码另查64张原尺寸定位帧（首轮20张，本轮事件补核44张）。

**边界：这不是逐帧观看，也不是准确率100%的人工逐字听写。** 机器转录误认较多，尤以英文函数、芯片名和数字为甚。下列关键配置已按原尺寸画面交叉核实；尚未核实的逐字措辞不能直接引用。没有实物板卡验收记录，不能把视频中的编译成功写成硬件验证成功。

## 1. 原始视频与覆盖

| 视频 | 时长 | 最后一条语音转录至 | 全轴采样帧 |
|---|---:|---:|---:|
| 演示STDLIB标准库新建工程 | 8:30.500 | 8:29.230 | 26 |
| 演示STM32CubeMX新建工程 | 15:58.000 | 15:56.960 | 32 |
| GPIO流水灯：HAL法 | 20:16.601 | 20:15.480 | 41 |
| GPIO流水灯：标准库STD法 | 22:31.400 | 22:30.680 | 45 |
| 演示STM32汇编语言 | 10:15.900 | 10:14.900 | 21 |

原件链接：
- [SPL新建工程](https://drive.google.com/file/d/1eZ3OqHzSFt5WKUvtYL4vOfbnIAFsdkVN/view)
- [CubeMX新建工程](https://drive.google.com/file/d/1QHl9C0TbRynSvDk-UhzPKI6H46yD-yIr/view)
- [HAL流水灯](https://drive.google.com/file/d/1WUPIvZK2o6cRg6w-QLnkPIFsBuKh2Ib1/view)
- [SPL流水灯](https://drive.google.com/file/d/1TXgXmDKF0x7eF5P2X5FxYOSMEr9YlFD1/view)
- [汇编](https://drive.google.com/file/d/1RLW3tQnyWnAlEFWp_eVrIhQIqcXAJFET/view)

## 2. SPL新建工程：照着做时必须保留的步骤

1. 0:50–1:35：复制老师模板的三个目录，工程保存在UserMain目录中；新建目标STM32F407ZGTx。
2. 2:05–2:20：该模板已经包含核心和外设相关文件，本段演示不再重复选RTE组件。
3. 2:20–4:30：Manage Project Items建立Startup、STDLIB、User组，添加各组源文件。最终画面为startup_stm32f40xx.s；misc.c、stm32f4xx_gpio.c、stm32f4xx_rcc.c、stm32f4xx_syscfg.c；stm32f4xx_it.c、system_stm32f4xx.c、Usermain.c。
4. 5:20–6:15：C/C++设置宏 **STM32F40_41xxx, USE_STDPERIPH_DRIVER**，补齐UserMain、启动文件Include目录及标准库inc目录。宏正确不等于头文件搜索路径正确，两项分开检查。
5. 6:20–6:55：调试器按真实硬件选CMSIS-DAP等；教师明确当前未接硬件，因此目标信息灰色。
6. 7:10–7:25：遇编译错误，ARM Compiler从6改为5。教材应说明这是旧模板兼容处理，不把“所有工程必须AC5”推广为普遍定律。
7. 7:30–7:55：stm32f4xx_it.c引用main.h报错，改为usermain.h。8:10结果0 Errors、1 Warning。模板头文件重命名后必须同步所有引用。
8. 8:10：SysTick_Config(HCLK_Frequency/100)产生10ms节拍，因此Delay(5)约50ms。主循环中的应用代码之后再填。

## 3. CubeMX新建工程：从图形配置到可编辑工程

- 0:45–1:30选STM32F407ZGTx；1:55–2:10建议英文路径。此为演示环境要求，不能凭空断言所有当前版本都不支持中文。
- 3:00–3:40：SYS选Serial Wire，PA13/PA14用于SWD；Timebase为SysTick。
- 3:40–4:10：演示开启HSE、LSE晶体选项；4:30–5:35：PE3设置GPIO输出并命名。
- 7:30–10:35：调整时钟树。**最终主时钟不是168MHz，而是167.5MHz**：HSE25MHz、M20、N268、P2；AHB/1，APB1/4=41.875MHz，APB2/2=83.75MHz。9:55–10:08语音说明接受接近值以节省演示时间。10:35 RTC最终切到LSE32.768kHz。
- 10:40–12:00：Project Manager选MDK-ARM；Copy all used libraries；按外设分成.c/.h；Keep User Code；示例固件包STM32Cube FW_F4 V1.27.1。
- 12:00–14:30：查看Core、Drivers、MDK-ARM及生成工程并编译。此演示导入所有库，教师说明后续可只选必要库以减少编译时间。
- 15:20–15:50：应用代码写在USER CODE BEGIN 3/END 3之间；区外内容可能在重新生成时被覆盖。

## 4. GPIO两种库：共同硬件、不同构建与计时

### 共同点
- 板上PE3接LED2；PB0–PB7接八个流水灯。课件电路是3.3V经电阻与LED连接到GPIO，因此**低电平点亮，高电平熄灭**。
- 每轮先让八个PB脚全高，再将数组GPIO_PIN[Number]选中的一路置低；Number加一，到8回零。
- 初始化要先确保GPIOB/GPIOE时钟使能，配置输出模式，再进入应用循环。SPL示例另外初始化PE4，但本题主心跳使用PE3。
- 所谓“呼吸灯（心跳指示灯）”在此代码中是数字翻转闪烁，并没有PWM占空比渐变。

### HAL实证
- 4:15时钟：HSE8MHz、M8、N336、P2 →168MHz；APB1=42MHz，APB2=84MHz。这与CubeMX新建示例25MHz/167.5MHz不同，不能混抄。
- 8:05最终GPIO表：PE3、PB0–PB7初始High，Output Push Pull、Pull-up、Very High。7:45表格仍处逐脚修改中，不能当最终设置。
- 11:30–13:20：检查自动生成MX_GPIO_Init、时钟使能及HAL_Init/SystemClock_Config/MX_GPIO_Init顺序。
- 15:45–16:20：把标准库逻辑迁到HAL时替换不兼容API。
- 16:52–18:15：HAL_Delay(100)，每5步翻转PE3，得到约500ms翻转、1s完整亮灭周期；流水每100ms一步，8灯约0.8s一圈。原代码Index为uint16_t，自然回卷时会有一次分频边界扰动；改稿可用显式5回零分频计数或非阻塞tick差值。
- 18:15编译0 Errors、0 Warnings；没有实物波形或板卡运行验收。

### SPL实证
- 2:55附近此段选CMSIS Core，再手工引入厂商外设库。与“SPL新建工程”视频RTE留空的路径不同：应以实际模板保证只有一套核心/启动实现，避免重复定义。
- 8:45–9:10语音与最终代码均确认SysTick为10ms；Delay(n)不是HAL_Delay的毫秒参数。
- 11:00–14:00编LED_init，GPIOB/GPIOE在AHB1总线上；PE3/PE4、PB0–PB7配置推挽、上拉、100MHz速度及默认高电平。
- 14:15–15:35加入Delay(20)、GPIO_ToggleBits(GPIOE,GPIO_Pin_3)。15:32语音明确“隔200毫秒才取反一次”。
- 18:30附近修正GPIO_PIN数组：各引脚元素用逗号分隔，不是按位或。位掩码是多引脚同时操作，数组是逐一选择，两种写法目的不同。
- 19:45与22:15最终代码仍每200ms翻转心跳，每200ms移动流水灯。因此心跳完整亮灭约400ms，即约2.5Hz，**与课件1Hz目标有差异**。这是程序语义推算，非硬件实测。作业若要求1Hz，必须单独设置500ms翻转任务。
- 最终编译0 Errors、0 Warnings。

## 5. 汇编：应作为调试练习，不当成完整应用模板

- 0:39 About已核：µVision V5.35.0.0、MDK-ARM Plus5.35.0.2，当时选中ArmClang/Armasm/Armlink V6.16。不要与SPL后续选ARM Compiler5混为一谈。
- 1:30–2:15选CMSIS Core和Device Startup；查看启动汇编与system_stm32f4xx.c。
- 3:30–5:10添加Test.s，AREA/ENTRY/EXPORT __main；MOV、ADD、BL、BX LR。
- 5:20–5:50选择MicroLIB及Simulator，明确不依赖开发板；5:10编译0错误、1条L6314W警告。
- 6:15–7:20跟踪向量表、Reset_Handler、SystemInit再进入用户代码。
- 7:30左右用寄存器观察R5=5+0x233=0x238。
- 8:00–8:45返回流程不符合预期，教师注释BL func01后单独演示func02；不要宣称原代码完整验证无误。
- 10:05最终func02画面是R7从8递减到0后，再R6从7递减到0，两段**顺序循环**，不是7×8双重嵌套循环。练习应让学生手工追踪PC/LR/寄存器，并为主程序补明确的结束/停驻路径。

## 6. 可直接转成作业验收问题

1. 标出真实板卡晶振值，计算PLL、APB及定时器时钟，区分演示值与自己的配置。
2. 解释为什么“SET全灯后RESET一路”能形成单灯流水，并绘制有效电平关系。
3. 用时序表说明每次翻转间隔与完整闪烁频率的关系，改写SPL使心跳满足1Hz。
4. 说明SPL Delay(20)与HAL_Delay(20)为什么不可直接视为相等。
5. 演示宏缺失、include路径错误、main.h改名漏改引用各会出现什么诊断；保留修复前后构建记录。
6. CubeMX重新生成前后检查USER CODE内容，说明源文件结构与框架代码边界。
7. 汇编跟踪BL/BX LR，指出两段递减循环的真实次数与原例返回路径问题。
8. 编译、模拟器调试和板卡实测分别提供证据，不用一种结果冒充另一种。
