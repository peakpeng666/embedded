# 视频操作与知识索引（事件补核版）

本索引覆盖五段全部音轨中的教学内容与画面操作阶段，合并重复鼠标移动、等待编译及重复解释。已阅读1787段全长音轨转录；先用165张全轴采样定位，再查20张关键帧及本轮44张事件帧。**这是按教学事件覆盖核验，不是逐帧审阅或无误逐字听写。** 时间均相对视频起点。

证据标记：**画**＝可读画面；**音**＝连续讲解转录与上下文可辨、专有名词另外按画面校验；**两者**＝两者相互印证。资料应以最终状态为准；中途状态/临时编辑/教师口述意图不能当作最终完成证据。

## A. 演示STDLIB标准库新建工程（8:30）

| 时段 | 操作与教学知识 | 证据、边界 |
|---|---|---|
| 0:00–0:41 | 目标是先搭空白工程，后续第五章再加入外设功能；对应课件4.3 | 两者；不是本段已实现流水灯 |
| 0:42–1:35 | 打开Keil，找到并复制三个模板目录；工程存于UserMain | 两者；分组与磁盘目录是两个层面 |
| 1:36–2:05 | New Project，保存Test2，选择STM32F407系列/ZG目标 | 两者；2:00选型框还在展开途中，最终目标由7:20确认 |
| 2:05–2:20 | 关闭RTE选择，模板已含所需核心和外设 | 两者；2:12 CORE未勾，不照搬到所有项目 |
| 2:20–3:05 | 右键/Project菜单/工具按钮进入Manage Project Items；创建Startup组，加入启动.s文件 | 两者；3:00已添加startup_stm32f40xx.s |
| 3:05–3:55 | 创建STDLIB，按功能选misc.c、gpio.c、rcc.c、syscfg.c | 两者；教师提醒全库盲加不利定位问题 |
| 3:55–4:30 | User组加入中断、系统、用户main源文件，展开工程树确认 | 两者；添加到磁盘不等于添加到构建 |
| 4:30–5:10 | 查看Usermain.c、main/Delay/while框架、模板包版本 | 两者；源码头部V1.8.0；口述年份不当版本权威 |
| 5:10–5:45 | 从说明复制STM32F40_41xxx,USE_STDPERIPH_DRIVER到Define | 两者；5:30与6:15可读，精确大小写/下划线已核 |
| 5:45–6:18 | Include Paths加入UserMain、STM32F4xx_Startup/Include、STM32F4xx_StdPeriph_Driver/inc | 两者；6:15完整路径列表可辨 |
| 6:18–6:55 | Debug按板上下载器选CMSIS-DAP等 | 两者；教师明确未接硬件，不能写“连接成功” |
| 7:00–7:25 | 首次构建报错/旧CMSIS头警告，Target把ARM Compiler6改5 | 两者；7:09警告、7:20编译器选项；所有滚动错误未逐条确定 |
| 7:25–7:58 | 剩main.h找不到：跳到stm32f4xx_it.c第32行，改usermain.h | 两者；7:31错误原文、7:45修复编辑 |
| 7:58–8:30 | 编译后0错误1警告；说明用户代码填main中的while | 两者；8:10仍显示1 Warning，不写成零警告 |
| 8:10附近 | HCLK/100产生10ms tick；Delay(5)约50ms | 画与框架讲解；单位不能与HAL_Delay混淆 |

## B. 演示STM32CubeMX新建工程（15:58）

| 时段 | 操作与教学知识 | 证据、边界 |
|---|---|---|
| 0:00–0:45 | 用CubeMX向导建立HAL框架，再填应用层 | 音；不要把向导等同完成应用 |
| 0:45–1:30 | MCU Selector搜索407，选择STM32F407ZGT6/STM32F407ZGTx，LQFP144 | 两者；1:13明确商业型号与封装 |
| 1:30–2:45 | 浏览Pinout/Clock/Project Manager并保存Test1.ioc，建英文目录 | 两者；英文路径是示范环境建议 |
| 2:45–3:40 | SYS Debug=Serial Wire，PA13=SWDIO、PA14=SWCLK，Timebase=SysTick | 两者；3:15可读；ASR把PA误作PS不可照抄 |
| 3:40–4:15 | RCC启用HSE、LSE Crystal/Ceramic Resonator，对应外部晶振引脚 | 两者；4:10两者皆启用，非HAL流水灯的仅HSE情形 |
| 4:15–5:35 | PE3选GPIO_Output并命名LED0；初始Low、Push Pull、Pull-up、Low速度 | 两者；5:30最终表，此处不是LED2/初始High/VeryHigh |
| 5:35–6:28 | 简介ADC/DAC、定时器；RTC勾Activate Clock Source | 两者；6:23只勾时钟源，Activate Calendar未勾，不能称实现日历 |
| 6:28–7:15 | 浏览CAN/以太网、音频/摄像头、安全/CRC、中间件菜单 | 两者；这是能力介绍，没有配置这些外设 |
| 7:15–8:25 | HSE25MHz经主PLL作为SYSCLK，尝试倍/分频 | 两者；不能把中途16/168.75等值当最终 |
| 8:25–10:08 | 多轮静音/少量讲解调整M/N/P、APB分频，红色超限提示逐步消除 | 画；9:55口述接受“接近”值，试算过程不逐次复制到教程 |
| 10:08–10:35 | 最终M20/N268/P2→167.5MHz；AHB/1，APB1/4=41.875，APB2/2=83.75；RTC切LSE32.768kHz | 两者；10:20主时钟已定但RTC仍LSI，10:35才是RTC最终 |
| 10:35–11:08 | Project Manager选MDK-ARM，Min Version V5.32，Heap0x200、Stack0x400 | 画10:55；Min Version不是本机µVision实际版本 |
| 11:08–11:45 | Copy all used libraries；每外设.c/.h；Keep User Code；不勾Backup；勾Delete obsolete generated files | 两者；与HAL流水灯选择只复制必要库不同 |
| 11:45–12:15 | Generate Code成功，打开目录/工程，固件包FW_F4 V1.27.1 | 两者；11:55成功对话框 |
| 12:15–13:50 | 看Core用户源、Drivers HAL/CMSIS、MDK启动文件与gpio/rtc/main；说明入口与无限循环 | 两者；确实生成GPIO和RTC初始化 |
| 13:50–14:35 | 编译框架成功；指出全库编译较慢；检查宏USE_HAL_DRIVER,STM32F407xx及自动Include Paths | 两者；14:35为有效0错误0警告构建结果 |
| 14:35–15:15 | Debug改选CMSIS-DAP，调试器应匹配真实板子；查看工程分组 | 两者；并无下载完成/运行证据 |
| 15:15–15:58 | USER CODE BEGIN 3/END 3范围演示；临时在内外输入占位字符展示区别 | 两者；15:45 main.c*未保存并有hhhh/ssss，底部0错误来自旧构建，不能当当前文字可编译 |

## C. GPIO流水灯——HAL法（20:16）

| 时段 | 操作与教学知识 | 证据、边界 |
|---|---|---|
| 0:00–0:37 | 课件目标：PE3心跳与PB0–7八灯流水；LED电路低有效 | 两者；PB100ms不是课件题干硬要求 |
| 0:37–1:15 | CubeMX New Project选STM32F407ZGTx | 两者 |
| 1:15–1:53 | SYS Serial Wire/SysTick，讲PA13/PA14调试 | 两者 |
| 1:53–2:37 | HSE外部晶振启用，LSE本例不用；PH0/PH1为HSE引脚 | 两者；不要与通用CubeMX双晶振示范合并 |
| 2:37–4:15 | HSE8MHz，PLL M8/N336/P2；SYSCLK168，APB1=42、APB2=84，定时器84/168 | 两者；红色中途状态不作最终依据 |
| 4:15–6:20 | PE3输出名LED2；PB0–PB7输出逐个命名YLED0–YLED7 | 两者；总9路参与本功能 |
| 6:20–8:05 | 逐脚改初始High、推挽、上拉、Very High；最后核总表 | 两者；7:45仍有PB6/PB7未完成；8:05全部完成；速度不代表灯刷新频率 |
| 8:05–9:10 | 保存TES3及英文路径，MDK-ARM Min V5.32，FW_F4 V1.27.1 | 两者；嵌套目录只是演示命名，不需原样照搬 |
| 9:10–9:40 | Copy only necessary library files，分.c/.h、Keep User Code；生成工程 | 两者；9:20选择明确，不是全库复制 |
| 9:40–10:30 | 生成并打开PDF配置报告，浏览引脚与配置说明 | 两者；这是配置报告，不是实验测量报告 |
| 10:30–11:30 | Keil展开启动、应用、HAL驱动、CMSIS；定位main/gpio | 两者 |
| 11:30–13:00 | MX_GPIO_Init中看RCC时钟使能、初始SET、结构体Pin/Mode/Pull/Speed及HAL_GPIO_Init | 两者；15:05补帧清楚显示PE3/PB0–7配置与先写电平 |
| 13:00–13:55 | main初始化顺序HAL_Init→SystemClock_Config→MX_GPIO_Init；先编框架 | 两者；不是手填一份替代生成代码 |
| 13:55–14:25 | 配置下载器/Flash Download；依真实板选，查看复位运行设置 | 两者；14:10还为ST-Link，之后选CMSIS-DAP，中途不可当唯一指定 |
| 14:25–15:20 | 从旧代码复制引脚宏/数组与Number等变量；可用CubeMX生成宏或显式GPIO_PIN_n | 两者；标识符应保持同一套命名 |
| 15:20–16:25 | 误粘SPL GPIO_ToggleBits/SetBits/ResetBits，编辑器提示implicit declaration；换成HAL函数 | 两者；15:55明确SPL API错用于HAL；不是“加个头文件就行” |
| 16:25–17:00 | 调整HAL_Delay位置和1000→100：中途if后紧接Delay，后来移到if前 | 两者；16:25是暂态错位，最后if仅控制TogglePin |
| 17:00–18:20 | 每100ms一步，Index%5时PE3翻转；全SET再RESET当前PB，Number到8回零，Index++；最终编译0/0 | 两者；18:15最终代码；约1Hz是理论完整周期，非实测；uint16 Index回卷边界另作改进说明 |
| 18:20–19:15 | 总结CubeMX搭框架/应用填空，回配置页再回main解释功能代码 | 两者；18:40/18:50只是看表，19:00回代码，未取得“实际再生成验证保留”的证据 |
| 19:15–20:16 | 右键跳HAL_GPIO_TogglePin定义，读库函数意义，说明WritePin/ReadPin等可按应用选择 | 两者；库源码浏览不是实物测试 |

## D. GPIO流水灯——标准库STD法（22:31）

| 时段 | 操作与教学知识 | 证据、边界 |
|---|---|---|
| 0:00–1:02 | 说明PE3与PB0–7、电路与两种库实现路线 | 两者；课件指定心跳1Hz，但后面实现未保持该频率 |
| 1:02–2:30 | 从老师资源复制模板3目录，新建TES3/UserMain工程 | 两者 |
| 2:30–3:15 | 选器件及CMSIS核心；厂商外设库手加 | 音及后续CMSIS树；3:00帧仍未勾，不能拿该帧说已完成选择 |
| 3:15–4:15 | 打开Pack Installer说明缺器件包时找到ST→STM32F407ZG，已有包显示Up to date | 两者；只展示已有安装状态，没有实际新安装全过程 |
| 4:15–6:15 | Startup、Stdlib、User分组与文件；解释misc支持中断，按功能选库 | 两者 |
| 6:15–7:35 | Define宏与三个Include目录 | 两者；21:15回顾最终设置 |
| 7:35–8:00 | CMSIS-DAP/SW设置，No Debug Unit Device found | 两者；7:45清晰，无板卡连接成功证据 |
| 8:00–8:30 | 编译器6产生错误/警告，改5后构建 | 两者；8:10显示7 errors/21 warnings的中途结果，不混到最终 |
| 8:30–9:15 | 解释SysTick10ms，Delay(5)=50ms，随后修改初始延时 | 两者；留下旧注释时以真实代码为准 |
| 9:15–10:45 | main前声明LED_init并在文件下方定义，不拆独立驱动文件便于初学 | 两者 |
| 10:45–12:10 | GPIO_InitTypeDef，RCC_AHB1PeriphClockCmd使能B/E；解释GPIO所在AHB1 | 两者；11:15代码原文可读 |
| 12:10–13:10 | PE3/PE4推挽/上拉/GPIO_High_Speed；GPIO_Init后SET使灯默认灭 | 两者；虽然题目用PE3，这里顺便初始化PE4 |
| 13:10–14:00 | PB0–7同样初始化并SET，main调用LED_init | 两者 |
| 14:00–15:35 | 加Delay(20)，查GPIO库定义并选择ToggleBits(GPIOE,Pin3) | 两者；15:32明确“200毫秒取反”，非500ms |
| 15:35–17:00 | 每次全SET八脚，ResetBits选一个，解释低有效流水 | 两者；15:45明确200ms移位是本例实现取值 |
| 17:00–18:20 | 引入GPIO_PIN数组与Number，Number++、等8归零；替换旧自定义符号成标准GPIO_Pin_n | 两者 |
| 18:20–19:00 | 数组初始值误以竖线连接，教师指出应逗号，逐项修复 | 两者；18:40仍混有竖线，18:55已全逗号；位掩码与数组用途不同 |
| 19:00–20:50 | 编译0/0，总结模板/分组/初始化/应用顺序并回看代码 | 两者；19:45仍Delay20+每轮toggle，完整周期约400ms=2.5Hz |
| 20:50–22:31 | 回顾Compiler5、宏、Include、下载器、Reset and Run；强调初始化有固定格式，应用逻辑可变化 | 两者；22:15最终代码没有改为1Hz，不能把“实现功能”口述替代频率验算 |

## E. 演示STM32汇编语言（10:15）

| 时段 | 操作与教学知识 | 证据、边界 |
|---|---|---|
| 0:00–0:45 | 汇编入门/无目标板；About查看µVision5.35.0.0、MDK5.35.0.2、当时工具链6.16 | 两者；00:39原帧含许可证信息，不发布原帧，只摘版本文字 |
| 0:45–1:30 | 新建工程Tetris，选择ST F4/ZG器件 | 两者 |
| 1:30–2:20 | RTE勾CMSIS Core、Device Startup，其他不选 | 两者；1:48/2:12勾选完成；CORE5.5.0、Startup2.6.3为组件信息而非IDE版本 |
| 2:20–3:30 | 展开startup.s与system_stm32f4xx.c，解释向量/系统初始化/系统时钟 | 两者；不能用SystemCoreClock初始变量16MHz断言所有工程主时钟16MHz |
| 3:30–4:10 | Add New Item建Test.s，复制示例 | 两者 |
| 4:10–5:05 | AREA/ENTRY/EXPORT __main；MOV R0=50、R1=101；BL func01/func02；ADD与BX LR | 两者；程序短小，不等同完整可交付主程序 |
| 5:05–5:20 | 编译，0错误1警告L6314W | 画5:10；“没错”是无error，不是无warning |
| 5:20–5:50 | 勾Use MicroLIB、选Use Simulator；与开发板无关 | 两者；5:25/5:40设置可读，此工程仍选Compiler6 |
| 5:50–6:15 | 进入Debug，介绍单步进入/跨过子程序、寄存器/反汇编窗口 | 两者；口述对两个按钮有重复/含糊，按钮功能按工具实际定义说明，不逐字照引 |
| 6:15–7:20 | 看向量表前两项__initial_sp与Reset_Handler，再看LDR/BLX SystemInit、LDR/BX __main | 两者；6:35/7:10原画可辨；地址0/4为向量偏移说明，非一律物理Flash绝对地址 |
| 7:20–8:00 | 单步加法，观察R5=0x238 | 两者；5+0x233按十六进制解释 |
| 8:00–8:55 | 发现返回/推进不如预期，尝试调试后注释BL func01，重新构建再试func02 | 两者；8:37编辑、8:55新调试可读，不称彻底修复返回结构 |
| 8:55–9:30 | 单步或运行到光标；观察寄存器、时间、SP及xPSR N/Z/C等 | 两者；模拟时间不自动代表真实硬件计时 |
| 9:30–10:15 | func02两个顺序倒计数循环R7=8、R6=7，CBZ/NOP/SUBS/B，最后BX LR；强调后续更多用C实现 | 两者；10:05无回到LOOP7的外循环，不是7×8嵌套循环 |

## 新旧/中途/最终的统一口径

1. **题目 vs 实现**：PE3 1Hz是课件目标；PB100ms为HAL示例选值，SPL示例PB200ms。不能把100ms写为老师统一指定。
2. **通用CubeMX vs HAL GPIO**：前者HSE25→167.5MHz、PE3名LED0/初始Low/Low速、复制全部库、启LSE/RTC时钟；后者HSE8→168MHz、PE3名LED2/初始High/VeryHigh、只复制必要库、无RTC需求。
3. **UI版本 vs 编译器 vs固件包**：µVision5.35、ARM Compiler5或6、FW_F4 V1.27.1、MDK最低V5.32、CMSIS组件版本各不相同。
4. **中途代码不当终稿**：SPL数组竖线→逗号；HAL先错用SPL API，再更换HAL API；HAL_Delay1000先处if之后，最后100移到if之前；通用CubeMX结尾占位字符未重编。
5. **编译/连接/实测分层**：字幕或底部旧0错误不能替代当前构建；灰色下载器/No Debug Unit不是连接成功；模拟器寄存器不是板卡LED实测。

## 明确仍未判定或不宜过度解读的时段

- **SPL新建7:00–7:15、SPL GPIO8:00–8:15**：编译输出滚动，已知编译器兼容变化与部分头文件诊断；未逐条恢复全部错误因果，不能说每条都由同一个根因导致。
- **通用CubeMX8:25–10:08**：静音调PLL过程中每次暂态尝试没有逐个抄录；最终参数已清楚，暂态数字不影响教学结论。未得到CubeMX应用自身完整About版本。
- **通用CubeMX15:15–15:58**：占位文字展示位置，未取得重新生成后保留/删除的实际对照构建；只确认为教师讲述的规则与位置演示。
- **HAL18:20–19:15**：没有可确认的重新生成成功对话框；因此不说“该段已实测重新生成保留用户代码”。
- **汇编8:00–8:55**：返回推进问题被隔离演示，未证明原两调用布局已经修复；主程序落入后续子程序的风险可以作为代码审查推论，不伪称教师已完整解释根因。
- **汇编5:50–6:15**：口述单步按钮有含糊重复；不逐字用作按钮定义。可以让学生依据Step Into/Step Over实际操作验证。
- **全部硬件相关段**：板卡实际晶振/接线/下载运行/示波器波形均未形成完整实证链；必须用工程/原理图与用户实板补验。

上述未定项均已限定，不影响已核的时钟、引脚、API、计时差异与关键修错结论。无需为重复鼠标移动、文件夹临时命名等无关动作无限扩充。


## 可读画面附录

下列相对链接均指向本附录随包图片；可直接打开核对，不含原始视频、转录初稿或运行记录。其他操作按本索引视频时间戳回看原件。

- [SPL预处理宏，5:30](evidence/spl_new_project_330.jpg)
- [SPL编译器选项，7:20](evidence/spl_new_project_440.jpg)
- [main.h引用错误与修正，7:45](evidence/spl_new_project_465.jpg)
- [CubeMX最终167.5MHz与LSE，10:35](evidence/cube_new_project_635.jpg)
- [通用CubeMX PE3初始Low与Low速，5:30](evidence/cube_new_project_330.jpg)
- [HAL示例168MHz，4:15](evidence/hal_gpio_255.jpg)
- [HAL最终GPIO初始High与VeryHigh，8:05](evidence/hal_gpio_485.jpg)
- [HAL只复制必要库，9:20](evidence/hal_gpio_560.jpg)
- [HAL错粘SPL API的中途诊断，15:55](evidence/hal_gpio_955.jpg)
- [HAL最终100ms步进与5次分频，18:15](evidence/hal_gpio_1095.jpg)
- [SPL10ms tick与Delay20，19:45](evidence/spl_gpio_1185.jpg)
- [SPL数组已改为逗号分隔，18:55](evidence/spl_gpio_1135.jpg)
- [汇编两个顺序倒计数循环，10:05](evidence/assembly_605.jpg)
